# AutoCombat v1.5.1

Plugin Paper 1.21.11 (Java 21), server-side. Jalan untuk pemain **Java** dan **Bedrock (Geyser/Floodgate)**.

## Fitur

- **Auto End Crystal** (`/autoendcrystal`, alias `/autocrystal`, `/aec`, `/endcrystal`): arahkan crosshair ke obsidian/bedrock -> crystal langsung dipasang dan diledakkan tiap tick. Crosshair ke crystal -> langsung diledakkan. Layar tidak digerakkan.
- **Auto Mace** (`/automace`, alias `/am`): kill aura jarak dekat (`mace.killaura-reach`, arah mana pun termasuk di belakang) + assist crosshair meleset (`mace.assist-angle`). Kamera mati secara default (`mace.camera: false`). Posisi dan kecepatan jatuh tidak diubah.
- **Auto Spear** (`/autospear`, alias `/spear`): hanya saat spear dipegang. Lompat + dash ke target + pukul, lalu otomatis pindah ke slot spear di sebelahnya dan ulangi. Kamera tidak disentuh. Taruh beberapa spear berdampingan di hotbar.

## Build

JDK 21 + Maven: `mvn package` -> `target/AutoCombat.jar`. Atau dorong ke GitHub, workflow `build-autocombat.yml` akan membangunnya.
Hapus `plugins/AutoCombat/config.yml` lama sebelum restart supaya config baru dibuat.

## Verifikasi pemain (console)

- `aimbot <player|uuid>` / `aimbot <player> off` / `aimbot list`
- Bedrock: `aimbot .Nama` atau `aimbot Nama`. Daftar di `plugins/AutoCombat/allowed.yml`.

## Permission

- `autocombat.admin` (untuk `/autocombat reload`)
