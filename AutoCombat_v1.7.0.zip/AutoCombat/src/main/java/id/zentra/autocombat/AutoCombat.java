package id.zentra.autocombat;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.WindCharge;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * AutoCombat v1.5.1 (Paper 1.21.x). Berjalan di sisi server, jadi pemain Java maupun
 * Bedrock (lewat Geyser/Floodgate) sama-sama bisa memakainya.
 */
public class AutoCombat extends JavaPlugin implements CommandExecutor, Listener {

    /** Status Auto Mace per pemain. */
    private static final class MaceState {
        UUID lock;                 // target yang sedang diikuti kamera (kalau kamera dinyalakan)
        long engageTick = -1;      // kamera baru mulai bergerak setelah tick ini (waktu reaksi)
        long lastRot = -1000;      // tick terakhir kamera digerakkan
        long nextAttack = 0;       // tick paling cepat untuk pukulan berikutnya
        double nx, ny, nz;         // offset titik bidik di dalam hitbox (-1..1)
        double cx, cy, cz;         // offset yang sedang dipakai (menyusul nx,ny,nz pelan-pelan)
        long noiseUntil = 0;       // kapan offset diacak ulang
        int rotations = 0;         // jumlah koreksi kamera pada jatuhan ini
        float vYaw, vPitch;        // kecepatan putar kamera saat ini (derajat/tick), diperhalus
    }

    private final Set<UUID> crystalOn = new HashSet<>();
    private final Set<UUID> maceOn = new HashSet<>();
    private final Set<UUID> spearOn = new HashSet<>();
    private final Set<UUID> pearlOn = new HashSet<>();
    private final Set<UUID> hitOn = new HashSet<>();
    private final Set<UUID> hitboxOn = new HashSet<>();
    private final Set<UUID> hitboxOn = new HashSet<>();
    private final Set<EntityType> hitboxMobs = new HashSet<>();
    private final Set<UUID> allowed = new HashSet<>();
    private final Map<UUID, Long> lastCrystalAction = new HashMap<>();
    private final Map<UUID, Long> lastSpearDash = new HashMap<>();
    private final Map<UUID, Long> lastSpearAttack = new HashMap<>();
    private final Map<UUID, MaceState> maceStates = new HashMap<>();
    private final Map<UUID, MaceState> hitStates = new HashMap<>();
    private final Map<UUID, Long> lastPearlCombo = new HashMap<>();
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private final Set<Material> crystalBases = EnumSet.noneOf(Material.class);
    private long tickCounter = 0;
    private long lastHitboxTick = 0;
    private int hbBudget = 0;
    private File allowedFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        allowedFile = new File(getDataFolder(), "allowed.yml");
        loadAllowed();
        loadBases();
        loadHitboxTypes();
        getCommand("aimbot").setExecutor(this);
        getCommand("autoendcrystal").setExecutor(this);
        getCommand("automace").setExecutor(this);
        getCommand("autospear").setExecutor(this);
        getCommand("autopearl").setExecutor(this);
        getCommand("autohit").setExecutor(this);
        getCommand("hitbox").setExecutor(this);
        getCommand("autohitbox").setExecutor(this);
        getCommand("autocombat").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        startTask();
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (allowed.contains(online.getUniqueId())) grant(online);
        }
    }

    @Override
    public void onDisable() {
        Bukkit.getScheduler().cancelTasks(this);
        for (UUID id : new HashSet<>(attachments.keySet())) {
            Player online = Bukkit.getPlayer(id);
            if (online != null) revoke(online);
        }
        attachments.clear();
        crystalOn.clear();
        maceOn.clear();
        spearOn.clear();
        pearlOn.clear();
        hitOn.clear();
        hitboxOn.clear();
        hitStates.clear();
        lastPearlCombo.clear();
        lastCrystalAction.clear();
        lastSpearDash.clear();
        lastSpearAttack.clear();
        maceStates.clear();
    }

    private void loadBases() {
        crystalBases.clear();
        List<String> names = getConfig().getStringList("crystal.base-blocks");
        if (names.isEmpty()) names = List.of("OBSIDIAN", "BEDROCK");
        for (String n : names) {
            Material m = Material.matchMaterial(n);
            if (m != null) crystalBases.add(m);
            else getLogger().warning("crystal.base-blocks: material tidak dikenal: " + n);
        }
        if (crystalBases.isEmpty()) {
            crystalBases.add(Material.OBSIDIAN);
            crystalBases.add(Material.BEDROCK);
        }
    }

    private void startTask() {
        Bukkit.getScheduler().cancelTasks(this);
        long interval = Math.max(1, getConfig().getLong("tick-interval", 1));
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            tickCounter += interval;
            for (UUID id : new HashSet<>(crystalOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && canAct(p)) doCrystal(p);
            }
            for (UUID id : new HashSet<>(maceOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && canAct(p)) doMace(p);
            }
            for (UUID id : new HashSet<>(spearOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && canAct(p)) doSpear(p);
            }
            for (UUID id : new HashSet<>(hitOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && canAct(p)) doAutoHit(p);
            }
            if (!hitboxOn.isEmpty()
                    && tickCounter - lastHitboxTick >= Math.max(1, getConfig().getInt("hitbox.interval", 3))) {
                lastHitboxTick = tickCounter;
                for (UUID id : new HashSet<>(hitboxOn)) {
                    Player p = Bukkit.getPlayer(id);
                    if (p != null && p.isOnline() && allowed.contains(id)) doHitbox(p);
                }
            }
            for (UUID id : new HashSet<>(hitboxOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && p.isOnline()) doHitbox(p);
            }
        }, interval, interval);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (allowed.contains(p.getUniqueId())) grant(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        attachments.remove(id);
        clearState(id);
    }

    /**
     * Permission autocombat.use hanya diberikan ke pemain terverifikasi. Pemain lain tidak melihat
     * command-nya di tab-complete (termasuk daftar command Bedrock) dan tidak bisa menjalankannya.
     */
    private void grant(Player p) {
        if (attachments.containsKey(p.getUniqueId())) return;
        PermissionAttachment a = p.addAttachment(this);
        a.setPermission("autocombat.use", true);
        attachments.put(p.getUniqueId(), a);
        p.updateCommands();
    }

    private void revoke(Player p) {
        PermissionAttachment a = attachments.remove(p.getUniqueId());
        if (a != null) {
            try {
                p.removeAttachment(a);
            } catch (IllegalArgumentException ignored) {
            }
            p.updateCommands();
        }
    }

    private void clearState(UUID id) {
        crystalOn.remove(id);
        maceOn.remove(id);
        spearOn.remove(id);
        pearlOn.remove(id);
        hitOn.remove(id);
        hitboxOn.remove(id);
        hitStates.remove(id);
        lastPearlCombo.remove(id);
        lastCrystalAction.remove(id);
        lastSpearDash.remove(id);
        lastSpearAttack.remove(id);
        maceStates.remove(id);
    }

    private boolean canAct(Player p) {
        if (!p.isOnline() || p.isDead()) return false;
        GameMode gm = p.getGameMode();
        return gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE || gm == GameMode.CREATIVE;
    }

    // ------------------------------------------------------------------
    // UMUM
    // ------------------------------------------------------------------

    private boolean isAttackable(Player self, LivingEntity le, boolean hitMobs, boolean ignoreCreative) {
        if (le.equals(self) || le.isDead() || !le.isValid() || le instanceof ArmorStand) return false;
        if (le instanceof Player other) {
            GameMode gm = other.getGameMode();
            if (gm == GameMode.SPECTATOR) return false;
            return !(ignoreCreative && gm == GameMode.CREATIVE);
        }
        return hitMobs;
    }

    private Location center(LivingEntity le) {
        return le.getLocation().add(0, le.getHeight() / 2, 0);
    }

    private List<LivingEntity> findTargets(Player self, double range, boolean hitMobs, boolean ignoreCreative) {
        List<LivingEntity> list = new ArrayList<>();
        for (LivingEntity le : self.getWorld().getNearbyLivingEntities(self.getLocation(), range)) {
            if (isAttackable(self, le, hitMobs, ignoreCreative)) list.add(le);
        }
        final Location origin = self.getLocation();
        list.sort(Comparator.comparingDouble((LivingEntity e) -> e.getLocation().distanceSquared(origin)));
        return list;
    }

    // ------------------------------------------------------------------
    // AUTO END CRYSTAL
    // Hanya saat crystal dipegang. TIDAK menggerakkan layar sama sekali.
    // ------------------------------------------------------------------

    private void doCrystal(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack mainHand = inv.getItemInMainHand();
        ItemStack offHand = inv.getItemInOffHand();
        boolean inMain = mainHand.getType() == Material.END_CRYSTAL;
        boolean inOff = offHand.getType() == Material.END_CRYSTAL;
        if (!inMain && !inOff) return;

        FileConfiguration c = getConfig();
        long delay = c.getLong("crystal.action-delay", 2);
        long last = lastCrystalAction.getOrDefault(p.getUniqueId(), -1000L);
        if (tickCounter - last < delay) return;

        // Mode crosshair (default): tidak menunggu target, cukup arahkan crosshair ke obsidian
        if ("crosshair".equalsIgnoreCase(c.getString("crystal.mode", "crosshair"))) {
            crystalCrosshair(p, c, inMain);
            return;
        }

        // ---- Mode target (lama): hanya jalan kalau ada target di dekat ----
        double targetRange = c.getDouble("crystal.target-range", 8.0);
        double maxDist = c.getDouble("crystal.obsidian-max-distance", 2.0);
        double placeReach = c.getDouble("crystal.place-reach", 4.5);
        double breakReach = c.getDouble("crystal.break-reach", 4.5);
        double minSelf = c.getDouble("crystal.min-self-distance", 0.0);
        boolean instant = c.getBoolean("crystal.instant-break", true);

        List<LivingEntity> targets = findTargets(p, targetRange,
                c.getBoolean("crystal.hit-mobs", true),
                c.getBoolean("crystal.ignore-creative-spectator", true));
        if (targets.isEmpty()) return;

        Location eye = p.getEyeLocation();

        // 1) Ledakkan crystal yang sudah ada di dekat target
        for (LivingEntity t : targets) {
            for (Entity e : t.getNearbyEntities(maxDist + 3, maxDist + 3, maxDist + 3)) {
                if (!(e instanceof EnderCrystal crystal)) continue;
                double dist = crystal.getLocation().distance(eye);
                if (dist <= breakReach && dist >= minSelf) {
                    p.attack(crystal);
                    p.swingMainHand();
                    markCrystal(p);
                    return;
                }
            }
        }

        // 2) Cari base dekat target, pilih yang paling dekat
        Block bestBase = null;
        double bestDist = Double.MAX_VALUE;
        int radius = (int) Math.ceil(maxDist);

        for (LivingEntity t : targets) {
            Location tl = t.getLocation();
            Block feet = tl.getBlock();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    for (int dy = -radius - 1; dy <= radius; dy++) {
                        Block base = feet.getRelative(dx, dy, dz);
                        if (!crystalBases.contains(base.getType())) continue;
                        if (!base.getRelative(0, 1, 0).isEmpty()) continue;

                        Location spot = base.getLocation().add(0.5, 1.0, 0.5);

                        double distTarget = spot.distance(tl);
                        if (distTarget > maxDist) continue;

                        double distPlayer = spot.distance(eye);
                        if (distPlayer > placeReach || distPlayer < minSelf) continue;

                        if (spotBlocked(spot)) continue;

                        if (distTarget < bestDist) {
                            bestDist = distTarget;
                            bestBase = base;
                        }
                    }
                }
            }
        }

        if (bestBase == null) return;

        // 3) Pasang crystal (diledakkan di aksi berikutnya, atau langsung kalau instant-break)
        Location spawnLoc = bestBase.getLocation().add(0.5, 1.0, 0.5);
        EnderCrystal placed = bestBase.getWorld().spawn(spawnLoc, EnderCrystal.class,
                cr -> cr.setShowingBottom(false));
        consumeCrystal(p, inMain);
        p.swingMainHand();
        if (instant) p.attack(placed);
        markCrystal(p);
    }

    /**
     * Crosshair mode: arahkan crosshair ke obsidian/bedrock -> crystal langsung dipasang dan diledakkan.
     * Arahkan crosshair ke crystal -> langsung diledakkan. Tidak perlu ada target di dekat.
     * Layar tidak pernah digerakkan.
     */
    private void crystalCrosshair(Player p, FileConfiguration c, boolean inMain) {
        double placeReach = c.getDouble("crystal.place-reach", 4.5);
        double breakReach = c.getDouble("crystal.break-reach", 4.5);
        double minSelf = c.getDouble("crystal.min-self-distance", 0.0);
        boolean instant = c.getBoolean("crystal.instant-break", true);

        Location eye = p.getEyeLocation();
        Vector start = eye.toVector();
        RayTraceResult blockHit = p.rayTraceBlocks(Math.max(placeReach, breakReach));
        double blockDist = blockHit == null ? Double.MAX_VALUE : blockHit.getHitPosition().distance(start);

        // 1) Crystal tepat di crosshair -> ledakkan
        RayTraceResult ent = p.getWorld().rayTraceEntities(eye, eye.getDirection(), breakReach, 0.3,
                e -> e instanceof EnderCrystal);
        if (ent != null && ent.getHitEntity() instanceof EnderCrystal crystal) {
            double d = ent.getHitPosition().distance(start);
            if (d <= blockDist + 0.5 && crystal.getLocation().distance(eye) >= minSelf) {
                p.attack(crystal);
                p.swingMainHand();
                markCrystal(p);
                return;
            }
        }

        // 2) Obsidian/bedrock di crosshair -> pasang crystal
        if (blockHit == null || blockHit.getHitBlock() == null) return;
        Block base = blockHit.getHitBlock();
        if (!crystalBases.contains(base.getType())) return;
        if (!base.getRelative(0, 1, 0).isEmpty()) return;

        Location spot = base.getLocation().add(0.5, 1.0, 0.5);
        double dist = spot.distance(eye);
        if (dist > placeReach || dist < minSelf) return;
        if (spotBlocked(spot)) return;

        EnderCrystal placed = base.getWorld().spawn(spot, EnderCrystal.class, cr -> cr.setShowingBottom(false));
        consumeCrystal(p, inMain);
        p.swingMainHand();
        if (instant) p.attack(placed);
        markCrystal(p);
    }

    /** Catat aksi crystal; jitter acak kecil supaya ritmenya tidak kaku. */
    private void markCrystal(Player p) {
        int jitter = Math.max(0, getConfig().getInt("crystal.delay-jitter", 1));
        long extra = jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0;
        lastCrystalAction.put(p.getUniqueId(), tickCounter + extra);
    }

    private void consumeCrystal(Player p, boolean inMain) {
        if (p.getGameMode() == GameMode.CREATIVE) return;
        PlayerInventory inv = p.getInventory();
        if (inMain) {
            ItemStack it = inv.getItemInMainHand();
            it.setAmount(it.getAmount() - 1);
            inv.setItemInMainHand(it.getAmount() <= 0 ? null : it);
        } else {
            ItemStack it = inv.getItemInOffHand();
            it.setAmount(it.getAmount() - 1);
            inv.setItemInOffHand(it.getAmount() <= 0 ? null : it);
        }
    }

    // Ruang crystal (1x2x1 di atas base) tidak boleh ditempati makhluk lain / crystal lain
    private boolean spotBlocked(Location spot) {
        for (Entity e : spot.getWorld().getNearbyEntities(spot.clone().add(0, 1.0, 0), 0.5, 1.0, 0.5)) {
            if (e instanceof LivingEntity || e instanceof EnderCrystal) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // AUTO MACE
    // - kill aura: pemain dalam jarak dekat kena walau di belakang, crosshair agak meleset tetap kena
    // - kamera (opsional, default mati): mengikuti target saat masih tinggi
    // - posisi dan kecepatan jatuh tidak pernah diubah
    // ------------------------------------------------------------------

    private void doMace(Player p) {
        FileConfiguration c = getConfig();
        UUID id = p.getUniqueId();
        MaceState st = maceStates.computeIfAbsent(id, k -> new MaceState());

        // Terbang dengan elytra: kalau sudah dekat/di atas kepala lawan -> ganti ke mace dan pukul sekali
        if (p.isGliding() && c.getBoolean("mace.elytra-mode", true)) {
            doMaceElytra(p, st, c);
            return;
        }

        boolean falling = !p.isOnGround() && !p.isGliding()
                && p.getFallDistance() >= c.getDouble("mace.min-fall-distance", 1.5);
        boolean onlyFalling = c.getBoolean("mace.only-while-falling", true);

        if (!falling) {
            st.lock = null;
            st.engageTick = -1;
            st.rotations = 0;
            st.vYaw = 0;
            st.vPitch = 0;
            if (onlyFalling) return;
        }

        PlayerInventory inv = p.getInventory();
        if (inv.getItemInMainHand().getType() != Material.MACE) {
            if (!c.getBoolean("mace.auto-switch", false)) return;
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack it = inv.getItem(i);
                if (it != null && it.getType() == Material.MACE) {
                    slot = i;
                    break;
                }
            }
            if (slot == -1) return;
            inv.setHeldItemSlot(slot);
        }

        boolean hitMobs = c.getBoolean("mace.hit-mobs", true);

        // 1) Kamera (default MATI). Kalau dinyalakan: hanya aktif saat masih tinggi di atas target.
        if (falling && c.getBoolean("mace.camera", false)) {
            LivingEntity lock = getLock(p, st, c.getDouble("mace.aim-range", 8.0),
                    c.getDouble("mace.aim-vertical", 25.0), c.getDouble("mace.aim-fov", 120.0), hitMobs);
            if (lock != null) {
                if (st.engageTick < 0) {
                    int rt = Math.max(0, c.getInt("mace.reaction-ticks", 4));
                    st.engageTick = tickCounter + rt + (rt > 0 ? ThreadLocalRandom.current().nextInt(3) : 0);
                }
                if (tickCounter >= st.engageTick) {
                    aimAt(p, st, lock, cameraAllowed(p, st, lock, c), aimParams(p, c, "mace."));
                }
            }
        }

        // 2) Pukul otomatis
        if (!c.getBoolean("mace.auto-attack", true)) return;
        if (tickCounter < st.nextAttack) return;

        double reach = c.getDouble("mace.reach", 3.1);
        LivingEntity victim = null;
        // a) Kill aura jarak dekat: siapa pun dalam killaura-reach kena, walau di belakang kita
        double killReach = c.getDouble("mace.killaura-reach", 2.0);
        if (killReach > 0) victim = nearestInReach(p, killReach, hitMobs);
        // b) Crosshair agak meleset: target dalam jangkauan dan masih dalam sudut assist-angle
        if (victim == null) victim = coneTarget(p, reach, c.getDouble("mace.assist-angle", 40.0), hitMobs);
        // c) Tepat di crosshair (toleransi hitbox)
        if (victim == null) victim = facingTarget(p, reach, hitMobs);
        if (victim == null) return;

        p.attack(victim);
        p.swingMainHand();

        long interval = c.getLong("mace.attack-interval", 34);
        int jitter = Math.max(0, c.getInt("mace.attack-jitter", 3));
        st.nextAttack = tickCounter + interval + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
        st.lock = null;
        st.engageTick = -1;
        st.rotations = 0;
    }

    /** Mode elytra: lawan 1-2 blok di bawah/di atas kepala atau menempel -> ganti ke mace, pukul SEKALI. */
    private void doMaceElytra(Player p, MaceState st, FileConfiguration c) {
        if (tickCounter < st.nextAttack) return;
        boolean hitMobs = c.getBoolean("mace.hit-mobs", true);
        double horiz = c.getDouble("mace.elytra-horizontal", 1.8);
        double above = c.getDouble("mace.elytra-above", 2.5);
        double below = c.getDouble("mace.elytra-below", 2.0);

        Location pl = p.getLocation();
        LivingEntity victim = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(pl, horiz + 1, above + below + 4, horiz + 1)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            Location tl = le.getLocation();
            double h = Math.hypot(tl.getX() - pl.getX(), tl.getZ() - pl.getZ());
            if (h > horiz) continue;
            double dy = pl.getY() - (tl.getY() + le.getHeight());   // tinggi kita di atas kepala target
            if (dy > above || dy < -below) continue;
            double d = h * h + dy * dy;
            if (d < bestDist) {
                bestDist = d;
                victim = le;
            }
        }
        if (victim == null) return;

        PlayerInventory inv = p.getInventory();
        if (inv.getItemInMainHand().getType() != Material.MACE) {
            if (!c.getBoolean("mace.elytra-switch", true)) return;
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack it = inv.getItem(i);
                if (it != null && it.getType() == Material.MACE) {
                    slot = i;
                    break;
                }
            }
            if (slot == -1) return;
            inv.setHeldItemSlot(slot);
        }

        p.attack(victim);
        p.swingMainHand();
        long interval = c.getLong("mace.attack-interval", 34);
        int jitter = Math.max(0, c.getInt("mace.attack-jitter", 3));
        st.nextAttack = tickCounter + interval + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
    }

    /**
     * Kapan kamera TIDAK boleh disentuh sama sekali.
     * Kamera hanya bekerja saat masih tinggi di atas target; di dekat target tidak ada gerakan kamera.
     */
    private boolean cameraAllowed(Player p, MaceState st, LivingEntity target, FileConfiguration c) {
        Location pl = p.getLocation();
        Location tl = target.getLocation();
        double heightAbove = pl.getY() - tl.getY();
        if (heightAbove <= c.getDouble("mace.camera-off-height", 4.0)) return false;
        double horizontal = Math.hypot(tl.getX() - pl.getX(), tl.getZ() - pl.getZ());
        if (horizontal < c.getDouble("mace.min-horizontal", 1.5)) return false;      // hampir tepat di atas
        double dist = center(target).distance(p.getEyeLocation());
        if (dist <= c.getDouble("mace.stop-camera-within", 4.0)) return false;       // sudah dekat
        int max = c.getInt("mace.max-rotations", 0);
        if (max > 0 && st.rotations >= max) return false;                            // batas per jatuhan
        return true;
    }

    /** Target terdekat dalam jangkauan yang masih dalam sudut tertentu dari arah pandang (crosshair agak meleset). */
    private LivingEntity coneTarget(Player p, double reach, double angle, boolean hitMobs) {
        if (angle <= 0) return null;
        Location eye = p.getEyeLocation();
        Vector look = eye.getDirection();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(eye, reach + 2)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            Vector to = center(le).toVector().subtract(eye.toVector());
            double d = to.length();
            if (d > reach || d < 1.0E-6) continue;
            if (Math.toDegrees(look.angle(to)) > angle) continue;
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    /** Target yang benar-benar tepat di crosshair (ray dari mata ke hitbox, dengan toleransi). */
    private LivingEntity facingTarget(Player p, double reach, boolean hitMobs) {
        Location eye = p.getEyeLocation();
        Vector start = eye.toVector();
        Vector dir = eye.getDirection();
        double expand = getConfig().getDouble("mace.hit-expand", 0.25);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(eye, reach + 2)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            RayTraceResult r = le.getBoundingBox().clone().expand(expand).rayTrace(start, dir, reach);
            if (r == null) continue;
            double d = r.getHitPosition().distance(start);
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    /** Target terdekat dalam jarak tertentu dari mata, ke arah mana pun (kill aura). */
    private LivingEntity nearestInReach(Player p, double reach, boolean hitMobs) {
        Location eye = p.getEyeLocation();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), reach + 2)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            double d = center(le).distance(eye);
            if (d <= reach && d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    // Target kunci dipertahankan selama masih valid, supaya kamera tidak berpindah-pindah
    private LivingEntity getLock(Player p, MaceState st, double range, double vertical, double fov, boolean hitMobs) {
        if (st.lock != null) {
            Entity e = Bukkit.getEntity(st.lock);
            if (e instanceof LivingEntity le && validLock(p, le, range, vertical, hitMobs)) return le;
            st.lock = null;
            st.engageTick = -1;
        }

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        Location eye = p.getEyeLocation();
        Vector look = eye.getDirection();
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), range, vertical, range)) {
            if (!validLock(p, le, range, vertical, hitMobs)) continue;
            Vector to = center(le).toVector().subtract(eye.toVector());
            if (to.lengthSquared() < 1.0E-6) continue;
            if (Math.toDegrees(look.angle(to)) > fov) continue;
            double d = to.length();
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        if (best != null) st.lock = best.getUniqueId();
        return best;
    }

    private boolean validLock(Player p, LivingEntity le, double range, double vertical, boolean hitMobs) {
        if (!isAttackable(p, le, hitMobs, true)) return false;
        if (!le.getWorld().equals(p.getWorld())) return false;
        Location pl = p.getLocation();
        Location tl = le.getLocation();
        if (tl.getY() > pl.getY() + 0.5) return false;          // hanya yang di bawah
        if (pl.getY() - tl.getY() > vertical) return false;
        return Math.hypot(tl.getX() - pl.getX(), tl.getZ() - pl.getZ()) <= range;
    }

    /** Pemain Bedrock (Floodgate): UUID berawalan 0, atau nama berawalan titik. */
    private boolean isBedrock(Player p) {
        return p.getUniqueId().getMostSignificantBits() == 0L
                || p.getName().startsWith(getConfig().getString("bedrock.prefix", "."));
    }

    /** Parameter kamera. Bagian config: sec ("mace." / "autohit."), Bedrock punya nilai sendiri. */
    private record AimParams(int interval, float maxTurn, float deadzone, float smoothing, float accel,
                             double noise, float yawScale) {
    }

    private AimParams aimParams(Player p, FileConfiguration c, String sec) {
        boolean bedrock = isBedrock(p);
        String bs = sec.equals("mace.") ? "bedrock." : sec + "bedrock-";
        int interval = Math.max(1, bedrock ? c.getInt(bs + "rotation-interval", 3)
                : c.getInt(sec + "rotation-interval", 2));
        float maxTurn = (float) (bedrock ? c.getDouble(bs + "max-turn-speed", 2.5)
                : c.getDouble(sec + "max-turn-speed", 4.0));
        float yawScale = bedrock ? (float) Math.max(0.0, Math.min(1.0, c.getDouble(bs + "yaw-scale", 0.4))) : 1f;
        return new AimParams(interval, maxTurn,
                (float) c.getDouble(sec + "deadzone", 2.0),
                (float) Math.max(0.02, Math.min(1.0, c.getDouble(sec + "aim-smoothing", 0.12))),
                (float) Math.max(0.05, Math.min(1.0, c.getDouble(sec + "accel", 0.25))),
                Math.max(0.0, Math.min(0.9, c.getDouble(sec + "aim-noise", 0.25))),
                yawScale);
    }

    /**
     * Gerakkan kamera dengan kecepatan putar yang berubah pelan-pelan (bukan mulai/berhenti mendadak).
     * Posisi dan kecepatan gerak pemain tidak pernah diubah.
     */
    private void aimAt(Player p, MaceState st, LivingEntity target, boolean active, AimParams ap) {
        long since = tickCounter - st.lastRot;
        if (since < ap.interval()) return;
        float elapsed = Math.min(since, 4);
        st.lastRot = tickCounter;

        Location eye = p.getEyeLocation();
        float desYaw = 0f;
        float desPitch = 0f;

        boolean onTarget = target.getBoundingBox().clone().expand(0.05)
                .rayTrace(eye.toVector(), eye.getDirection(), 16.0) != null;

        if (active && !onTarget) {
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            if (tickCounter >= st.noiseUntil) {
                st.nx = rnd.nextDouble(-1, 1);
                st.ny = rnd.nextDouble(-1, 1);
                st.nz = rnd.nextDouble(-1, 1);
                st.noiseUntil = tickCounter + 8 + rnd.nextInt(9);
            }
            st.cx += (st.nx - st.cx) * 0.2;
            st.cy += (st.ny - st.cy) * 0.2;
            st.cz += (st.nz - st.cz) * 0.2;

            BoundingBox bb = target.getBoundingBox();
            double n = ap.noise();
            Vector aim = new Vector(
                    bb.getCenterX() + st.cx * (bb.getWidthX() / 2) * n,
                    bb.getCenterY() + st.cy * (bb.getHeight() / 2) * n,
                    bb.getCenterZ() + st.cz * (bb.getWidthZ() / 2) * n);

            Vector d = aim.subtract(eye.toVector());
            double horizontal = Math.hypot(d.getX(), d.getZ());
            float targetYaw = (float) Math.toDegrees(Math.atan2(-d.getX(), d.getZ()));
            float targetPitch = (float) Math.toDegrees(-Math.atan2(d.getY(), horizontal));

            float deltaYaw = horizontal < 0.35 ? 0f : wrap180(targetYaw - eye.getYaw());
            float deltaPitch = targetPitch - eye.getPitch();

            if (Math.abs(deltaYaw) >= ap.deadzone()) {
                desYaw = clamp(deltaYaw * ap.smoothing(), -ap.maxTurn(), ap.maxTurn()) * ap.yawScale();
            }
            if (Math.abs(deltaPitch) >= ap.deadzone()) {
                desPitch = clamp(deltaPitch * ap.smoothing(), -ap.maxTurn(), ap.maxTurn());
            }
        }

        st.vYaw += (desYaw - st.vYaw) * ap.accel();
        st.vPitch += (desPitch - st.vPitch) * ap.accel();

        // Terlalu kecil untuk berarti: jangan kirim paket rotasi sama sekali
        if (Math.abs(st.vYaw) < 0.05f && Math.abs(st.vPitch) < 0.05f) {
            st.vYaw = 0f;
            st.vPitch = 0f;
            return;
        }

        st.rotations++;
        p.setRotation(wrap180(eye.getYaw() + st.vYaw * elapsed),
                clamp(eye.getPitch() + st.vPitch * elapsed, -90f, 90f));
    }

    // ------------------------------------------------------------------
    // AUTO HIT (/autohit): seperti hit Java, satu klik per cooldown senjata, kamera mengikuti halus.
    // Aktif kalau ada target dalam jarak 1-2 blok.
    // ------------------------------------------------------------------

    private static double distToBox(Location eye, BoundingBox bb) {
        double dx = Math.max(Math.max(bb.getMinX() - eye.getX(), 0), eye.getX() - bb.getMaxX());
        double dy = Math.max(Math.max(bb.getMinY() - eye.getY(), 0), eye.getY() - bb.getMaxY());
        double dz = Math.max(Math.max(bb.getMinZ() - eye.getZ(), 0), eye.getZ() - bb.getMaxZ());
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private long hitInterval(ItemStack it, FileConfiguration c) {
        String n = it == null ? "" : it.getType().name();
        if (n.equals("MACE")) return c.getLong("autohit.interval-mace", 34);
        if (n.endsWith("_AXE")) return c.getLong("autohit.interval-axe", 22);
        if (n.endsWith("_SPEAR")) return c.getLong("autohit.interval-spear", 16);
        return c.getLong("autohit.interval", 13);
    }

    private void doAutoHit(Player p) {
        FileConfiguration c = getConfig();
        UUID id = p.getUniqueId();
        MaceState st = hitStates.computeIfAbsent(id, k -> new MaceState());
        boolean hitMobs = c.getBoolean("autohit.hit-mobs", true);
        double range = c.getDouble("autohit.range", 2.0);
        Location eye = p.getEyeLocation();

        // Pertahankan target yang sama supaya kamera tidak berpindah-pindah
        LivingEntity target = null;
        if (st.lock != null) {
            Entity e = Bukkit.getEntity(st.lock);
            if (e instanceof LivingEntity le && isAttackable(p, le, hitMobs, true)
                    && le.getWorld().equals(p.getWorld())
                    && distToBox(eye, le.getBoundingBox()) <= range + 0.5) {
                target = le;
            } else {
                st.lock = null;
            }
        }
        if (target == null) {
            double bestDist = Double.MAX_VALUE;
            for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), range + 2)) {
                if (!isAttackable(p, le, hitMobs, true)) continue;
                double d = distToBox(eye, le.getBoundingBox());
                if (d <= range && d < bestDist) {
                    bestDist = d;
                    target = le;
                }
            }
            if (target != null) st.lock = target.getUniqueId();
        }

        if (target == null) {
            st.vYaw = 0f;
            st.vPitch = 0f;
            return;
        }

        // Kamera halus mengikuti target
        if (c.getBoolean("autohit.camera", true)) {
            aimAt(p, st, target, true, aimParams(p, c, "autohit."));
        }

        // Satu klik per cooldown, hanya kalau sudah cukup menghadap target
        if (tickCounter < st.nextAttack) return;
        Vector to = center(target).toVector().subtract(eye.toVector());
        if (to.lengthSquared() > 1.0E-6
                && Math.toDegrees(eye.getDirection().angle(to)) > c.getDouble("autohit.attack-angle", 60.0)) {
            return;
        }

        p.attack(target);
        p.swingMainHand();
        long interval = hitInterval(p.getInventory().getItemInMainHand(), c);
        int jitter = Math.max(0, c.getInt("autohit.interval-jitter", 2));
        st.nextAttack = tickCounter + interval + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
    }

    // ------------------------------------------------------------------
    // HITBOX (/autohitbox): garis tepi hitbox RGB (bukan kotak penuh) pada pemain dan mob zombie.
    // Digambar dengan partikel yang hanya dikirim ke pemain yang mengaktifkannya.
    // ------------------------------------------------------------------

    private void loadHitboxTypes() {
        hitboxMobs.clear();
        List<String> names = getConfig().getStringList("hitbox.mobs");
        if (names.isEmpty()) names = List.of("ZOMBIE", "ZOMBIE_VILLAGER", "HUSK", "DROWNED");
        for (String n : names) {
            try {
                hitboxMobs.add(EntityType.valueOf(n.trim().toUpperCase()));
            } catch (IllegalArgumentException ex) {
                getLogger().warning("hitbox.mobs: jenis entity tidak dikenal: " + n);
            }
        }
    }

    private void doHitbox(Player p) {
        FileConfiguration c = getConfig();
        int every = Math.max(1, c.getInt("hitbox.interval", 3));
        if (tickCounter % every != 0) return;

        double range = c.getDouble("hitbox.range", 24.0);
        boolean players = c.getBoolean("hitbox.players", true);
        int max = Math.max(1, c.getInt("hitbox.max-entities", 20));
        double spacing = Math.max(0.1, c.getDouble("hitbox.spacing", 0.3));
        float size = (float) Math.max(0.2, c.getDouble("hitbox.size", 0.6));
        double speed = c.getDouble("hitbox.rgb-speed", 4.0);   // derajat hue per tick
        float hueBase = (float) (((tickCounter * speed) % 360.0) / 360.0);

        List<Entity> found = new ArrayList<>();
        for (Entity e : p.getNearbyEntities(range, range, range)) {
            if (!e.isValid()) continue;
            if (e instanceof Player other) {
                if (!players || !p.canSee(other) || other.getGameMode() == GameMode.SPECTATOR) continue;
                found.add(e);
            } else if (hitboxMobs.contains(e.getType())) {
                found.add(e);
            }
        }
        final Location origin = p.getLocation();
        found.sort(Comparator.comparingDouble((Entity e) -> e.getLocation().distanceSquared(origin)));

        int n = 0;
        for (Entity e : found) {
            if (n++ >= max) break;
            drawBox(p, e.getBoundingBox(), spacing, size, hueBase);
        }
    }

    /** Hanya 12 garis tepi kotak, warna berganti-ganti RGB sepanjang garis. */
    private void drawBox(Player viewer, BoundingBox b, double spacing, float size, float hueBase) {
        double x0 = b.getMinX(), x1 = b.getMaxX();
        double y0 = b.getMinY(), y1 = b.getMaxY();
        double z0 = b.getMinZ(), z1 = b.getMaxZ();
        float[] off = {0f};   // pergeseran warna antar garis
        // 4 garis sepanjang Y
        edge(viewer, x0, y0, z0, x0, y1, z0, spacing, size, hueBase, off);
        edge(viewer, x1, y0, z0, x1, y1, z0, spacing, size, hueBase, off);
        edge(viewer, x0, y0, z1, x0, y1, z1, spacing, size, hueBase, off);
        edge(viewer, x1, y0, z1, x1, y1, z1, spacing, size, hueBase, off);
        // 4 garis sepanjang X
        edge(viewer, x0, y0, z0, x1, y0, z0, spacing, size, hueBase, off);
        edge(viewer, x0, y1, z0, x1, y1, z0, spacing, size, hueBase, off);
        edge(viewer, x0, y0, z1, x1, y0, z1, spacing, size, hueBase, off);
        edge(viewer, x0, y1, z1, x1, y1, z1, spacing, size, hueBase, off);
        // 4 garis sepanjang Z
        edge(viewer, x0, y0, z0, x0, y0, z1, spacing, size, hueBase, off);
        edge(viewer, x1, y0, z0, x1, y0, z1, spacing, size, hueBase, off);
        edge(viewer, x0, y1, z0, x0, y1, z1, spacing, size, hueBase, off);
        edge(viewer, x1, y1, z0, x1, y1, z1, spacing, size, hueBase, off);
    }

    private void edge(Player viewer, double ax, double ay, double az, double bx, double by, double bz,
                      double spacing, float size, float hueBase, float[] off) {
        double len = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay) + (bz - az) * (bz - az));
        int steps = Math.max(1, (int) Math.ceil(len / spacing));
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            float hue = (hueBase + off[0] + (float) (t * 0.15)) % 1.0f;
            Particle.DustOptions dust = new Particle.DustOptions(hsvToColor(hue), size);
            viewer.spawnParticle(Particle.DUST, ax + (bx - ax) * t, ay + (by - ay) * t, az + (bz - az) * t,
                    1, 0, 0, 0, 0, dust);
        }
        off[0] = (off[0] + 0.08f) % 1.0f;
    }

    private static org.bukkit.Color hsvToColor(float h) {
        float hh = (h % 1.0f) * 6f;
        int i = (int) Math.floor(hh);
        float f = hh - i;
        float q = 1f - f;
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = 1f; g = f; b = 0f; }
            case 1 -> { r = q; g = 1f; b = 0f; }
            case 2 -> { r = 0f; g = 1f; b = f; }
            case 3 -> { r = 0f; g = q; b = 1f; }
            case 4 -> { r = f; g = 0f; b = 1f; }
            default -> { r = 1f; g = 0f; b = q; }
        }
        return org.bukkit.Color.fromRGB(Math.round(r * 255), Math.round(g * 255), Math.round(b * 255));
    }

    // ------------------------------------------------------------------
    // HITBOX (/hitbox): garis RGB di tepi hitbox pemain dan mob (hanya garis, tidak penuh).
    // Digambar dengan partikel yang HANYA dikirim ke pemain terverifikasi yang menyalakannya,
    // jadi pemain lain tidak melihat apa-apa. Memakai hitbox asli entity, jadi presisi.
    // ------------------------------------------------------------------

    private void doHitbox(Player p) {
        FileConfiguration c = getConfig();
        double range = c.getDouble("hitbox.range", 16.0);
        int maxEntities = Math.max(1, c.getInt("hitbox.max-entities", 6));
        boolean players = c.getBoolean("hitbox.players", true);
        Set<String> mobTypes = new HashSet<>();
        for (String n : c.getStringList("hitbox.mobs")) mobTypes.add(n.toUpperCase());

        List<LivingEntity> list = new ArrayList<>();
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), range)) {
            if (le.equals(p) || le.isDead() || !le.isValid()) continue;
            if (le instanceof Player other) {
                if (!players || other.getGameMode() == GameMode.SPECTATOR) continue;
            } else if (!mobTypes.contains(le.getType().name())) {
                continue;
            }
            list.add(le);
        }
        if (list.isEmpty()) return;
        final Location origin = p.getLocation();
        list.sort(Comparator.comparingDouble((LivingEntity e) -> e.getLocation().distanceSquared(origin)));

        double spacing = Math.max(0.2, c.getDouble("hitbox.spacing", 0.5));
        float size = (float) Math.max(0.2, c.getDouble("hitbox.size", 0.35));
        boolean dust = !"END_ROD".equalsIgnoreCase(c.getString("hitbox.particle", "DUST"));
        boolean rainbow = c.getBoolean("hitbox.rainbow", true);
        double hueBase = (tickCounter * c.getDouble("hitbox.rainbow-speed", 0.015)) % 1.0;
        int playerRgb = parseRgb(c.getString("hitbox.player-color", "FF0000"), 0xFF0000);
        int mobRgb = parseRgb(c.getString("hitbox.mob-color", "00FF00"), 0x00FF00);
        hbBudget = Math.max(50, c.getInt("hitbox.max-particles-per-update", 300));

        int count = 0;
        for (LivingEntity le : list) {
            if (count++ >= maxEntities || hbBudget <= 0) break;
            BoundingBox bb = le.getBoundingBox().clone().expand(0.02);
            int fixed = le instanceof Player ? playerRgb : mobRgb;
            drawBox(p, bb, spacing, size, dust, rainbow, fixed, hueBase);
        }
    }

    /** Gambar 12 rusuk kotak hitbox. */
    private void drawBox(Player p, BoundingBox bb, double spacing, float size, boolean dust,
                         boolean rainbow, int fixedRgb, double hueBase) {
        double[] xs = {bb.getMinX(), bb.getMaxX()};
        double[] ys = {bb.getMinY(), bb.getMaxY()};
        double[] zs = {bb.getMinZ(), bb.getMaxZ()};
        int edge = 0;
        for (double y : ys) {
            for (double z : zs) {
                hbLine(p, xs[0], y, z, xs[1], y, z, spacing, size, dust, rainbow, fixedRgb, hueBase, edge++);
            }
        }
        for (double x : xs) {
            for (double z : zs) {
                hbLine(p, x, ys[0], z, x, ys[1], z, spacing, size, dust, rainbow, fixedRgb, hueBase, edge++);
            }
        }
        for (double x : xs) {
            for (double y : ys) {
                hbLine(p, x, y, zs[0], x, y, zs[1], spacing, size, dust, rainbow, fixedRgb, hueBase, edge++);
            }
        }
    }

    private void hbLine(Player p, double ax, double ay, double az, double bx, double by, double bz,
                        double spacing, float size, boolean dust, boolean rainbow, int fixedRgb,
                        double hueBase, int edge) {
        double len = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay) + (bz - az) * (bz - az));
        int n = Math.max(1, (int) Math.ceil(len / spacing));
        for (int i = 0; i <= n; i++) {
            if (hbBudget-- <= 0) return;
            double t = (double) i / n;
            double x = ax + (bx - ax) * t;
            double y = ay + (by - ay) * t;
            double z = az + (bz - az) * t;
            if (dust) {
                int rgb = rainbow ? hsvToRgb((hueBase + t * 0.12 + edge * 0.03) % 1.0) : fixedRgb;
                p.spawnParticle(Particle.DUST, x, y, z, 1, 0, 0, 0, 0,
                        new Particle.DustOptions(Color.fromRGB(rgb), size));
            } else {
                p.spawnParticle(Particle.END_ROD, x, y, z, 1, 0, 0, 0, 0);
            }
        }
    }

    private static int parseRgb(String hex, int fallback) {
        try {
            return Integer.parseInt(hex.replace("#", "").trim(), 16) & 0xFFFFFF;
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    /** Warna pelangi penuh (saturasi dan kecerahan maksimum) dari hue 0..1. */
    private static int hsvToRgb(double h) {
        double hh = (h % 1.0) * 6.0;
        int i = (int) hh;
        double f = hh - i;
        double r;
        double g;
        double b;
        switch (i % 6) {
            case 0 -> { r = 1; g = f; b = 0; }
            case 1 -> { r = 1 - f; g = 1; b = 0; }
            case 2 -> { r = 0; g = 1; b = f; }
            case 3 -> { r = 0; g = 1 - f; b = 1; }
            case 4 -> { r = f; g = 0; b = 1; }
            default -> { r = 1; g = 0; b = 1 - f; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    // ------------------------------------------------------------------
    // AUTO ENDER PEARL + WIND CHARGE (/autopearl)
    // Saat kamu melempar ender pearl (klik kanan / tekan), wind charge otomatis dilempar sesaat
    // kemudian. Ada cooldown supaya tidak bisa di-spam. Wind charge diambil dari inventory.
    // ------------------------------------------------------------------

    @EventHandler(ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent e) {
        if (!(e.getEntity() instanceof EnderPearl)) return;
        if (!(e.getEntity().getShooter() instanceof Player p)) return;
        UUID id = p.getUniqueId();
        if (!pearlOn.contains(id) || !allowed.contains(id) || !canAct(p)) return;

        FileConfiguration c = getConfig();
        long cd = c.getLong("pearl.cooldown", 40);
        if (tickCounter - lastPearlCombo.getOrDefault(id, -1000L) < cd) return;
        lastPearlCombo.put(id, tickCounter);

        // Arah wind charge: mengikuti arah lemparan ender pearl (default), atau arah pandang / ke bawah
        String mode = c.getString("pearl.wind-direction", "pearl");
        Vector dir;
        if ("down".equalsIgnoreCase(mode)) {
            dir = new Vector(0, -1, 0);
        } else if ("look".equalsIgnoreCase(mode)) {
            dir = p.getEyeLocation().getDirection();
        } else {
            dir = e.getEntity().getVelocity().clone();
            if (dir.lengthSquared() < 1.0E-6) dir = p.getEyeLocation().getDirection();
        }
        final Vector windDir = dir.normalize();

        int delay = Math.max(0, c.getInt("pearl.wind-delay", 1));
        int jitter = Math.max(0, c.getInt("pearl.delay-jitter", 1));
        long wait = delay + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
        if (wait <= 0) {
            throwWindCharge(p, windDir);
        } else {
            Bukkit.getScheduler().runTaskLater(this, () -> throwWindCharge(p, windDir), wait);
        }
    }

    private void throwWindCharge(Player p, Vector dir) {
        if (!p.isOnline() || p.isDead()) return;
        PlayerInventory inv = p.getInventory();
        int slot = -1;
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (it != null && it.getType() == Material.WIND_CHARGE) {
                slot = i;
                break;
            }
        }
        boolean creative = p.getGameMode() == GameMode.CREATIVE;
        if (slot == -1 && !creative) return;

        p.launchProjectile(WindCharge.class, dir.clone().multiply(getConfig().getDouble("pearl.wind-speed", 1.5)));

        if (!creative) {
            ItemStack it = inv.getItem(slot);
            if (it != null) {
                it.setAmount(it.getAmount() - 1);
                inv.setItem(slot, it.getAmount() <= 0 ? null : it);
            }
        }
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float wrap180(float a) {
        a %= 360f;
        if (a >= 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    // ------------------------------------------------------------------
    // AUTO SPEAR (hanya saat spear dipegang)
    // Pukul otomatis secepat pemain laptop, lalu (opsional) pindah ke slot spear di sebelahnya.
    // Gerakan, lompat, dan dash TIDAK diubah plugin (tetap vanila). Kamera tidak digerakkan.
    // ------------------------------------------------------------------

    private static boolean isSpear(ItemStack it) {
        return it != null && it.getType().name().endsWith("_SPEAR");
    }

    private void doSpear(Player p) {
        if (!isSpear(p.getInventory().getItemInMainHand())) return;

        FileConfiguration c = getConfig();
        UUID id = p.getUniqueId();
        long interval = c.getLong("spear.attack-interval", 3);
        if (tickCounter - lastSpearAttack.getOrDefault(id, -1000L) < interval) return;

        boolean hitMobs = c.getBoolean("spear.hit-mobs", true);
        double reach = c.getDouble("spear.reach", 3.0);

        // Murni otomatisasi pukulan: gerakan, lompat, dan dash tetap dari pemain / vanila (lunge)
        LivingEntity victim = facingTarget(p, reach, hitMobs);
        if (victim == null) victim = coneTarget(p, reach, c.getDouble("spear.assist-angle", 25.0), hitMobs);
        if (victim == null) return;

        p.attack(victim);
        p.swingMainHand();

        int jitter = Math.max(0, c.getInt("spear.attack-jitter", 2));
        long last = tickCounter + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
        if (c.getBoolean("spear.auto-switch", true) && nextSpearSlot(p)) {
            last = tickCounter - interval + Math.max(0, c.getLong("spear.switch-delay", 2));
        }
        lastSpearAttack.put(id, last);
    }

    /** Pindah ke slot hotbar berikutnya yang berisi spear (berputar). true kalau berpindah. */
    private boolean nextSpearSlot(Player p) {
        PlayerInventory inv = p.getInventory();
        int cur = inv.getHeldItemSlot();
        for (int i = 1; i < 9; i++) {
            int slot = (cur + i) % 9;
            if (isSpear(inv.getItem(slot))) {
                inv.setHeldItemSlot(slot);
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // COMMANDS (senyap: tidak ada pesan chat)
    // ------------------------------------------------------------------

    private void feedback(Player p, String text) {
        if (!"actionbar".equalsIgnoreCase(getConfig().getString("feedback", "actionbar"))) return;
        p.sendActionBar(Component.text(text));
    }

    private void toggle(Player p, Set<UUID> set, String name, String arg) {
        UUID id = p.getUniqueId();
        boolean enable = arg == null ? !set.contains(id) : arg.equalsIgnoreCase("on");
        if (enable) set.add(id); else set.remove(id);
        maceStates.remove(id);
        hitStates.remove(id);
        feedback(p, name + (enable ? " ON" : " OFF"));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();

        // Verifikasi pemain: hanya lewat console, senyap untuk pemain
        if (name.equals("aimbot")) {
            if (sender instanceof Player) return true;
            handleVerify(sender, args);
            return true;
        }

        if (name.equals("autocombat")) {
            if (sender instanceof Player) return true;   // hanya console
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                loadAllowed();
                loadBases();
                loadHitboxTypes();
                startTask();
                for (Player online : Bukkit.getOnlinePlayers()) {
                    if (allowed.contains(online.getUniqueId())) grant(online); else revoke(online);
                }
                sender.sendMessage("AutoCombat direload.");
            }
            return true;
        }

        if (!(sender instanceof Player p)) return true;
        if (!allowed.contains(p.getUniqueId())) return true; // belum diverifikasi

        String arg = (args.length > 0 && (args[0].equalsIgnoreCase("on") || args[0].equalsIgnoreCase("off")))
                ? args[0] : null;

        if (name.equals("autoendcrystal")) {
            toggle(p, crystalOn, "Auto End Crystal", arg);
        } else if (name.equals("automace")) {
            toggle(p, maceOn, "Auto Mace", arg);
        } else if (name.equals("autospear")) {
            toggle(p, spearOn, "Auto Spear", arg);
        } else if (name.equals("autopearl")) {
            toggle(p, pearlOn, "Auto Pearl + Wind Charge", arg);
        } else if (name.equals("autohit")) {
            toggle(p, hitOn, "Auto Hit", arg);
        } else if (name.equals("hitbox")) {
            toggle(p, hitboxOn, "Hitbox", arg);
        } else if (name.equals("autohitbox")) {
            toggle(p, hitboxOn, "Hitbox", arg);
        }
        return true;
    }

    // ------------------------------------------------------------------
    // VERIFIKASI (console): aimbot <player|uuid> | aimbot <player> off | aimbot list
    // Nama Bedrock (Floodgate, mis. ".Nama") dan nama tanpa titik sama-sama dikenali.
    // ------------------------------------------------------------------

    private static String strip(String n) {
        int i = 0;
        while (i < n.length() && !Character.isLetterOrDigit(n.charAt(i)) && n.charAt(i) != '_') i++;
        return n.substring(i).replace(' ', '_');
    }

    private static boolean nameMatches(String a, String b) {
        return a.equalsIgnoreCase(b) || strip(a).equalsIgnoreCase(strip(b));
    }

    private OfflinePlayer resolvePlayer(String input) {
        try {
            return Bukkit.getOfflinePlayer(UUID.fromString(input));
        } catch (IllegalArgumentException ignored) {
        }
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (nameMatches(o.getName(), input)) return o;
        }
        for (OfflinePlayer o : Bukkit.getOfflinePlayers()) {
            String n = o.getName();
            if (n != null && nameMatches(n, input)) return o;
        }
        return null;
    }

    private void handleVerify(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("Pemakaian: aimbot <player|uuid> | aimbot <player> off | aimbot list");
            return;
        }

        if (args[0].equalsIgnoreCase("list")) {
            List<String> names = new ArrayList<>();
            for (UUID id : allowed) {
                String n = Bukkit.getOfflinePlayer(id).getName();
                names.add(n != null ? n : id.toString());
            }
            sender.sendMessage("Terverifikasi (" + names.size() + "): " + String.join(", ", names));
            return;
        }

        OfflinePlayer op = resolvePlayer(args[0]);
        if (op == null) {
            sender.sendMessage("Pemain " + args[0] + " belum pernah masuk server.");
            return;
        }

        UUID id = op.getUniqueId();
        boolean remove = args.length > 1
                && (args[1].equalsIgnoreCase("off") || args[1].equalsIgnoreCase("remove"));

        if (remove) {
            allowed.remove(id);
            clearState(id);
            Player online = Bukkit.getPlayer(id);
            if (online != null) revoke(online);
            sender.sendMessage("Verifikasi " + args[0] + " dicabut.");
        } else {
            allowed.add(id);
            Player online = Bukkit.getPlayer(id);
            if (online != null) grant(online);
            sender.sendMessage(args[0] + " terverifikasi (" + id + ").");
        }
        saveAllowed();
    }

    private void loadAllowed() {
        allowed.clear();
        if (allowedFile == null || !allowedFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(allowedFile);
        for (String s : y.getStringList("verified")) {
            try {
                allowed.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveAllowed() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> list = new ArrayList<>();
        for (UUID id : allowed) list.add(id.toString());
        y.set("verified", list);
        try {
            getDataFolder().mkdirs();
            y.save(allowedFile);
        } catch (IOException e) {
            getLogger().warning("Gagal menyimpan allowed.yml");
        }
    }
}
