# AutoCombat v1.7.0

Plugin Paper 1.21.11 (Java 21), server-side. Jalan untuk pemain **Java** dan **Bedrock (Geyser/Floodgate)**.

## Fitur

- **Auto End Crystal** (`/autoendcrystal`, alias `/autocrystal`, `/aec`, `/endcrystal`): arahkan crosshair ke obsidian/bedrock -> crystal langsung dipasang dan diledakkan tiap tick. Crosshair ke crystal -> langsung diledakkan. Layar tidak digerakkan.
- **Auto Mace** (`/automace`, alias `/am`): kill aura jarak dekat (`mace.killaura-reach`, arah mana pun termasuk di belakang) + assist crosshair meleset (`mace.assist-angle`). Kamera mati secara default (`mace.camera: false`). Posisi dan kecepatan jatuh tidak diubah.
- **Auto Spear** (`/autospear`, alias `/spear`): hanya saat spear dipegang. Pukul otomatis secepat pemain laptop (gerakan tetap vanila), lalu otomatis pindah ke slot spear di sebelahnya dan ulangi. Kamera tidak disentuh. Taruh beberapa spear berdampingan di hotbar.

- **Auto Pearl + Wind Charge** (`/autopearl`, alias `/apearl`): saat melempar ender pearl, wind charge otomatis dilempar sesaat kemudian (searah lemparan ender pearl). Ada cooldown 2 detik supaya tidak bisa di-spam. Wind charge diambil dari inventory.
- **Auto Hit** (`/autohit`, alias `/ah`): kalau ada target dalam 2 blok, memukul satu kali per cooldown senjata (ritme Java) dan kamera mengikuti target dengan halus.

- **Hitbox** (`/autohitbox`, alias `/hitbox`, `/hb`): garis tepi hitbox RGB (bukan kotak penuh) pada pemain dan mob zombie. Partikel hanya dikirim ke pemain yang mengaktifkannya.

- **Hitbox** (`/hitbox`, alias `/hb`): garis RGB di tepi hitbox pemain dan mob (default zombie; atur di `hitbox.mobs`). Hanya garis rusuk, tidak penuh. Partikel hanya dikirim ke pemain terverifikasi yang menyalakannya.

## Build

JDK 21 + Maven: `mvn package` -> `target/AutoCombat.jar`. Atau dorong ke GitHub, workflow `build-autocombat.yml` akan membangunnya.
Hapus `plugins/AutoCombat/config.yml` lama sebelum restart supaya config baru dibuat.

## Verifikasi pemain (console)

- `aimbot <player|uuid>` / `aimbot <player> off` / `aimbot list`
- Bedrock: `aimbot .Nama` atau `aimbot Nama`. Daftar di `plugins/AutoCombat/allowed.yml`.

## Keamanan

Semua fitur hanya untuk pemain yang diverifikasi lewat console. Pemain lain tidak bisa memakainya, tidak melihat command-nya, dan tidak mendapat respons. `aimbot` dan `autocombat reload` hanya bisa dari console. Plugin tidak mengubah pengaturan server apa pun.
