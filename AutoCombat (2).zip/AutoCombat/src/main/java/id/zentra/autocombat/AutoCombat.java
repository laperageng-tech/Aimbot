package id.zentra.autocombat;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class AutoCombat extends JavaPlugin implements CommandExecutor, Listener {

    private final Set<UUID> crystalOn = new HashSet<>();
    private final Set<UUID> maceOn = new HashSet<>();
    private final Map<UUID, Long> lastCrystalAction = new HashMap<>();
    private long tickCounter = 0;
    private final Set<UUID> allowed = new HashSet<>();
    private File allowedFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        allowedFile = new File(getDataFolder(), "allowed.yml");
        loadAllowed();
        getCommand("aimbot").setExecutor(this);
        getCommand("autocrystal").setExecutor(this);
        getCommand("automace").setExecutor(this);
        getCommand("autocombat").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        startTask();
    }

    @Override
    public void onDisable() {
        Bukkit.getScheduler().cancelTasks(this);
        crystalOn.clear();
        maceOn.clear();
        lastCrystalAction.clear();
    }

    private void startTask() {
        Bukkit.getScheduler().cancelTasks(this);
        long interval = Math.max(1, getConfig().getLong("tick-interval", 1));
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            tickCounter += interval;
            for (UUID id : new HashSet<>(crystalOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && canAct(p)) doCrystal(p);
            }
            for (UUID id : new HashSet<>(maceOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && canAct(p)) doMace(p);
            }
        }, interval, interval);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        crystalOn.remove(id);
        maceOn.remove(id);
        lastCrystalAction.remove(id);
    }

    private boolean canAct(Player p) {
        if (!p.isOnline() || p.isDead()) return false;
        GameMode gm = p.getGameMode();
        return gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE || gm == GameMode.CREATIVE;
    }

    // ------------------------------------------------------------------
    // AUTO END CRYSTAL (hanya saat crystal dipegang)
    // ------------------------------------------------------------------

    private void doCrystal(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack mainHand = inv.getItemInMainHand();
        ItemStack offHand = inv.getItemInOffHand();
        boolean inMain = mainHand.getType() == Material.END_CRYSTAL;
        boolean inOff = offHand.getType() == Material.END_CRYSTAL;
        if (!inMain && !inOff) return;

        FileConfiguration c = getConfig();
        long delay = c.getLong("crystal.action-delay", 2);
        long last = lastCrystalAction.getOrDefault(p.getUniqueId(), -1000L);
        if (tickCounter - last < delay) return;

        double targetRange = c.getDouble("crystal.target-range", 8.0);
        double breakReach = c.getDouble("crystal.break-reach", 4.5);
        double placeReach = c.getDouble("crystal.place-reach", 4.5);
        double minSelf = c.getDouble("crystal.min-self-distance", 3.5);
        double obsMin = c.getDouble("crystal.obsidian-min-distance", 1.0);
        double obsMax = c.getDouble("crystal.obsidian-max-distance", 2.0);

        Player target = findTargetPlayer(p, targetRange, c.getBoolean("crystal.ignore-creative-spectator", true));
        if (target == null) return;

        // 1) Pecahkan crystal yang sudah ada di dekat target
        for (Entity e : p.getWorld().getNearbyEntities(target.getLocation(), 4, 4, 4)) {
            if (!(e instanceof EnderCrystal crystal)) continue;
            double dist = crystal.getLocation().distance(p.getEyeLocation());
            if (dist <= breakReach && dist >= minSelf) {
                p.attack(crystal);
                p.swingMainHand();
                lastCrystalAction.put(p.getUniqueId(), tickCounter);
                return;
            }
        }

        // 2) Letakkan crystal baru di obsidian/bedrock, 1-2 blok dari target
        Location tl = target.getLocation();
        Block feet = tl.getBlock();
        int radius = (int) Math.ceil(obsMax) + 1;

        Block best = null;
        double bestDist = Double.MAX_VALUE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -2; dy <= 0; dy++) {
                    Block base = feet.getRelative(dx, dy, dz);
                    Material m = base.getType();
                    if (m != Material.OBSIDIAN && m != Material.BEDROCK) continue;
                    if (!base.getRelative(0, 1, 0).isEmpty()) continue;
                    if (!base.getRelative(0, 2, 0).isEmpty()) continue;

                    Location spot = base.getLocation().add(0.5, 1.0, 0.5);

                    double hd = Math.hypot(spot.getX() - tl.getX(), spot.getZ() - tl.getZ());
                    if (hd < obsMin || hd > obsMax) continue;

                    double distPlayer = spot.distance(p.getEyeLocation());
                    if (distPlayer > placeReach || distPlayer < minSelf) continue;

                    if (!base.getWorld().getNearbyEntities(spot.clone().add(0, 0.5, 0), 0.5, 1.0, 0.5).isEmpty()) continue;

                    if (hd < bestDist) {
                        bestDist = hd;
                        best = base;
                    }
                }
            }
        }

        if (best == null) return;

        Location spawnLoc = best.getLocation().add(0.5, 1.0, 0.5);
        best.getWorld().spawn(spawnLoc, EnderCrystal.class, cr -> cr.setShowingBottom(false));
        p.swingMainHand();

        if (p.getGameMode() != GameMode.CREATIVE) {
            if (inMain) {
                mainHand.setAmount(mainHand.getAmount() - 1);
                inv.setItemInMainHand(mainHand.getAmount() <= 0 ? null : mainHand);
            } else {
                offHand.setAmount(offHand.getAmount() - 1);
                inv.setItemInOffHand(offHand.getAmount() <= 0 ? null : offHand);
            }
        }
        lastCrystalAction.put(p.getUniqueId(), tickCounter);
    }

    private Player findTargetPlayer(Player self, double range, boolean ignoreCreativeSpectator) {
        Player best = null;
        double bestDist = Double.MAX_VALUE;
        for (Player other : self.getWorld().getPlayers()) {
            if (other.equals(self) || other.isDead()) continue;
            GameMode gm = other.getGameMode();
            if (ignoreCreativeSpectator && (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR)) continue;
            double d = other.getLocation().distance(self.getLocation());
            if (d <= range && d < bestDist) {
                bestDist = d;
                best = other;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------
    // AUTO MACE: layar ikut target di bawah saat jatuh (kamera saja)
    // ------------------------------------------------------------------

    private void doMace(Player p) {
        FileConfiguration c = getConfig();
        if (p.isOnGround() || p.isGliding() || p.getFallDistance() < c.getDouble("mace.min-fall-distance", 1.5)) return;

        PlayerInventory inv = p.getInventory();
        boolean holdingMace = inv.getItemInMainHand().getType() == Material.MACE;

        if (!holdingMace) {
            if (!c.getBoolean("mace.auto-switch", false)) return;
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack it = inv.getItem(i);
                if (it != null && it.getType() == Material.MACE) {
                    slot = i;
                    break;
                }
            }
            if (slot == -1) return;
            inv.setHeldItemSlot(slot);
        }

        double range = c.getDouble("mace.aim-range", 8.0);
        double vertical = c.getDouble("mace.aim-vertical", 25.0);
        boolean hitMobs = c.getBoolean("mace.hit-mobs", true);

        Location eye = p.getEyeLocation();
        LivingEntity target = null;
        double bestDist = Double.MAX_VALUE;

        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), range, vertical, range)) {
            if (le.equals(p) || le.isDead() || le instanceof ArmorStand) continue;
            if (le.getLocation().getY() > p.getLocation().getY() + 0.5) continue; // hanya yang di bawah
            if (le instanceof Player other) {
                GameMode gm = other.getGameMode();
                if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) continue;
            } else if (!hitMobs) {
                continue;
            }
            double d = le.getLocation().add(0, le.getHeight() / 2, 0).distance(eye);
            if (d < bestDist) {
                bestDist = d;
                target = le;
            }
        }
        if (target == null) return;

        // Arahkan layar ke target (halus), ikut bergerak selama target bergerak
        Location tp = target.getLocation().add(0, target.getHeight() / 2, 0);
        Vector d = tp.toVector().subtract(eye.toVector());
        float targetYaw = (float) Math.toDegrees(Math.atan2(-d.getX(), d.getZ()));
        float targetPitch = (float) Math.toDegrees(-Math.atan2(d.getY(), Math.hypot(d.getX(), d.getZ())));

        float s = (float) Math.max(0.05, Math.min(1.0, c.getDouble("mace.aim-smoothing", 0.35)));
        float newYaw = wrap180(eye.getYaw() + s * wrap180(targetYaw - eye.getYaw()));
        float newPitch = Math.max(-90f, Math.min(90f, eye.getPitch() + s * (targetPitch - eye.getPitch())));
        p.setRotation(newYaw, newPitch);

        // Pukul otomatis kalau dalam jangkauan
        if (c.getBoolean("mace.auto-attack", true)
                && inv.getItemInMainHand().getType() == Material.MACE
                && bestDist <= c.getDouble("mace.reach", 3.5)
                && p.getAttackCooldown() >= c.getDouble("mace.min-cooldown", 0.95)) {
            p.attack(target);
            p.swingMainHand();
        }
    }

    private static float wrap180(float a) {
        a %= 360f;
        if (a >= 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    // ------------------------------------------------------------------
    // COMMANDS (senyap: tidak ada pesan chat)
    // ------------------------------------------------------------------

    private void feedback(Player p, String text) {
        if (!"actionbar".equalsIgnoreCase(getConfig().getString("feedback", "off"))) return;
        p.sendActionBar(Component.text(text));
    }

    private void toggle(Player p, Set<UUID> set, String name, String arg) {
        UUID id = p.getUniqueId();
        boolean enable = arg == null ? !set.contains(id) : arg.equalsIgnoreCase("on");
        if (enable) set.add(id); else set.remove(id);
        feedback(p, name + (enable ? " ON" : " OFF"));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();

        // Verifikasi pemain: hanya lewat console, senyap untuk pemain
        if (name.equals("aimbot")) {
            if (sender instanceof Player) return true;
            handleVerify(sender, args);
            return true;
        }

        if (name.equals("autocombat")) {
            if (sender.hasPermission("autocombat.admin") && args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                loadAllowed();
                startTask();
            }
            return true;
        }

        if (!(sender instanceof Player p)) return true;
        if (!allowed.contains(p.getUniqueId())) return true; // belum diverifikasi

        String arg = (args.length > 0 && (args[0].equalsIgnoreCase("on") || args[0].equalsIgnoreCase("off")))
                ? args[0] : null;

        if (name.equals("autocrystal")) {
            toggle(p, crystalOn, "Auto Crystal", arg);
        } else if (name.equals("automace")) {
            toggle(p, maceOn, "Auto Mace", arg);
        }
        return true;
    }

    // ------------------------------------------------------------------
    // VERIFIKASI (console): aimbot <player> | aimbot <player> off | aimbot list
    // ------------------------------------------------------------------

    private void handleVerify(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("Pemakaian: aimbot <player> | aimbot <player> off | aimbot list");
            return;
        }

        if (args[0].equalsIgnoreCase("list")) {
            List<String> names = new ArrayList<>();
            for (UUID id : allowed) {
                String n = Bukkit.getOfflinePlayer(id).getName();
                names.add(n != null ? n : id.toString());
            }
            sender.sendMessage("Terverifikasi (" + names.size() + "): " + String.join(", ", names));
            return;
        }

        OfflinePlayer op = Bukkit.getPlayerExact(args[0]);
        if (op == null) op = Bukkit.getOfflinePlayerIfCached(args[0]);
        if (op == null) {
            sender.sendMessage("Pemain " + args[0] + " belum pernah masuk server.");
            return;
        }

        UUID id = op.getUniqueId();
        boolean remove = args.length > 1
                && (args[1].equalsIgnoreCase("off") || args[1].equalsIgnoreCase("remove"));

        if (remove) {
            allowed.remove(id);
            crystalOn.remove(id);
            maceOn.remove(id);
            lastCrystalAction.remove(id);
            sender.sendMessage("Verifikasi " + args[0] + " dicabut.");
        } else {
            allowed.add(id);
            sender.sendMessage(args[0] + " terverifikasi.");
        }
        saveAllowed();
    }

    private void loadAllowed() {
        allowed.clear();
        if (allowedFile == null || !allowedFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(allowedFile);
        for (String s : y.getStringList("verified")) {
            try {
                allowed.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveAllowed() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> list = new ArrayList<>();
        for (UUID id : allowed) list.add(id.toString());
        y.set("verified", list);
        try {
            getDataFolder().mkdirs();
            y.save(allowedFile);
        } catch (IOException e) {
            getLogger().warning("Gagal menyimpan allowed.yml");
        }
    }
}
