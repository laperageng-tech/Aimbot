# AutoCombat v1.2

Plugin Paper 1.21.11 (Java 21) berisi dua fitur dalam satu plugin:

- **Auto End Crystal** (`/autocrystal [on|off]`): aktif hanya saat End Crystal dipegang. Crystal ditaruh di obsidian/bedrock 1-2 blok dari target lalu dipecahkan.
- **Auto Mace** (`/automace [on|off]`): saat jatuh, layar bergeser mengarah ke target di bawah (pemain, mob, bot) dan mengikuti gerakannya. Pukul otomatis opsional.

Tidak ada pesan chat. Umpan balik toggle bisa dinyalakan lewat `feedback: "actionbar"` di `config.yml`.

## Build

Butuh JDK 21 dan Maven.

```
mvn package
```

Hasilnya `target/AutoCombat.jar`. Taruh di folder `plugins/` server lalu restart.

## Verifikasi pemain (lewat console)

Hanya pemain yang sudah diverifikasi yang bisa memakai `/autocrystal` dan `/automace`. Pemain lain tidak mendapat respons apa pun.

- `aimbot <player>`: verifikasi pemain
- `aimbot <player> off`: cabut verifikasi
- `aimbot list`: lihat daftar

Command `aimbot` hanya bisa dari console. Pemain yang sudah pernah masuk server bisa diverifikasi. Daftar disimpan di `plugins/AutoCombat/allowed.yml`.

## Permission

- `autocombat.admin` (untuk `/autocombat reload`)

## Pengaturan

Semua angka (jangkauan, delay, jarak obsidian, kehalusan aim, auto-attack, dll) ada di `plugins/AutoCombat/config.yml`.
