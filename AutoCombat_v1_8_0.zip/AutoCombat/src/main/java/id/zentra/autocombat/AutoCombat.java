package id.zentra.autocombat;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.WindCharge;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * AutoCombat v1.5.1 (Paper 1.21.x). Berjalan di sisi server, jadi pemain Java maupun
 * Bedrock (lewat Geyser/Floodgate) sama-sama bisa memakainya.
 */
public class AutoCombat extends JavaPlugin implements Listener {

    /** Status Auto Mace per pemain. */
    private static final class MaceState {
        UUID lock;                 // target yang sedang diikuti kamera (kalau kamera dinyalakan)
        long engageTick = -1;      // kamera baru mulai bergerak setelah tick ini (waktu reaksi)
        long lastRot = -1000;      // tick terakhir kamera digerakkan
        long nextAttack = 0;       // tick paling cepat untuk pukulan berikutnya
        double nx, ny, nz;         // offset titik bidik di dalam hitbox (-1..1)
        double cx, cy, cz;         // offset yang sedang dipakai (menyusul nx,ny,nz pelan-pelan)
        long noiseUntil = 0;       // kapan offset diacak ulang
        int rotations = 0;         // jumlah koreksi kamera pada jatuhan ini
        float vYaw, vPitch;        // kecepatan putar kamera saat ini (derajat/tick), diperhalus
    }

    private final Set<UUID> crystalOn = new HashSet<>();
    private final Set<UUID> maceOn = new HashSet<>();
    private final Set<UUID> spearOn = new HashSet<>();
    private final Set<UUID> pearlOn = new HashSet<>();
    private final Set<UUID> hitOn = new HashSet<>();
    private final Map<UUID, Long> lastCrystalAction = new HashMap<>();
    private final Map<UUID, Long> lastSpearDash = new HashMap<>();
    private final Map<UUID, Long> lastSpearAttack = new HashMap<>();
    private final Map<UUID, MaceState> maceStates = new HashMap<>();
    private final Map<UUID, MaceState> hitStates = new HashMap<>();
    private final Map<UUID, Long> lastPearlCombo = new HashMap<>();
    private final Set<Material> crystalBases = EnumSet.noneOf(Material.class);
    private long tickCounter = 0;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadBases();
        Bukkit.getPluginManager().registerEvents(this, this);
        startTask();
        getLogger().info("AutoCombat aktif.");
    }

    @Override
    public void onDisable() {
        Bukkit.getScheduler().cancelTasks(this);
    }

    private void loadBases() {
        crystalBases.clear();
        List<String> names = getConfig().getStringList("crystal.base-blocks");
        if (names.isEmpty()) names = List.of("OBSIDIAN", "BEDROCK");
        for (String n : names) {
            Material m = Material.matchMaterial(n);
            if (m != null) crystalBases.add(m);
            else getLogger().warning("crystal.base-blocks: material tidak dikenal: " + n);
        }
        if (crystalBases.isEmpty()) {
            crystalBases.add(Material.OBSIDIAN);
            crystalBases.add(Material.BEDROCK);
        }
    }

    private void startTask() {
        Bukkit.getScheduler().cancelTasks(this);
        long interval = Math.max(1, getConfig().getLong("tick-interval", 1));
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            tickCounter += interval;
            for (UUID id : new HashSet<>(crystalOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && p.isOp() && canAct(p)) doCrystal(p); else if (p == null || !p.isOp()) crystalOn.remove(id);
            }
            for (UUID id : new HashSet<>(maceOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && p.isOp() && canAct(p)) doMace(p); else if (p == null || !p.isOp()) maceOn.remove(id);
            }
            for (UUID id : new HashSet<>(spearOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && p.isOp() && canAct(p)) doSpear(p); else if (p == null || !p.isOp()) spearOn.remove(id);
            }
            for (UUID id : new HashSet<>(hitOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && p.isOp() && canAct(p)) doAutoHit(p); else if (p == null || !p.isOp()) hitOn.remove(id);
            }
        }, interval, interval);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!e.getPlayer().isOp()) clearState(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        clearState(e.getPlayer().getUniqueId());
    }

    private void clearState(UUID id) {
        crystalOn.remove(id);
        maceOn.remove(id);
        spearOn.remove(id);
        pearlOn.remove(id);
        hitOn.remove(id);
        hitStates.remove(id);
        lastPearlCombo.remove(id);
        lastCrystalAction.remove(id);
        lastSpearDash.remove(id);
        lastSpearAttack.remove(id);
        maceStates.remove(id);
    }

    private boolean canAct(Player p) {
        if (!p.isOnline() || p.isDead()) return false;
        GameMode gm = p.getGameMode();
        return gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE || gm == GameMode.CREATIVE;
    }

    // ------------------------------------------------------------------
    // UMUM
    // ------------------------------------------------------------------

    private boolean isAttackable(Player self, LivingEntity le, boolean hitMobs, boolean ignoreCreative) {
        if (le.equals(self) || le.isDead() || !le.isValid() || le instanceof ArmorStand) return false;
        if (le instanceof Player other) {
            GameMode gm = other.getGameMode();
            if (gm == GameMode.SPECTATOR) return false;
            return !(ignoreCreative && gm == GameMode.CREATIVE);
        }
        return hitMobs;
    }

    private Location center(LivingEntity le) {
        return le.getLocation().add(0, le.getHeight() / 2, 0);
    }

    private List<LivingEntity> findTargets(Player self, double range, boolean hitMobs, boolean ignoreCreative) {
        List<LivingEntity> list = new ArrayList<>();
        for (LivingEntity le : self.getWorld().getNearbyLivingEntities(self.getLocation(), range)) {
            if (isAttackable(self, le, hitMobs, ignoreCreative)) list.add(le);
        }
        final Location origin = self.getLocation();
        list.sort(Comparator.comparingDouble((LivingEntity e) -> e.getLocation().distanceSquared(origin)));
        return list;
    }

    // ------------------------------------------------------------------
    // AUTO END CRYSTAL
    // Hanya saat crystal dipegang. TIDAK menggerakkan layar sama sekali.
    // ------------------------------------------------------------------

    private void doCrystal(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack mainHand = inv.getItemInMainHand();
        ItemStack offHand = inv.getItemInOffHand();
        boolean inMain = mainHand.getType() == Material.END_CRYSTAL;
        boolean inOff = offHand.getType() == Material.END_CRYSTAL;
        if (!inMain && !inOff) return;

        FileConfiguration c = getConfig();
        long delay = c.getLong("crystal.action-delay", 2);
        long last = lastCrystalAction.getOrDefault(p.getUniqueId(), -1000L);
        if (tickCounter - last < delay) return;

        // Mode crosshair (default): tidak menunggu target, cukup arahkan crosshair ke obsidian
        if ("crosshair".equalsIgnoreCase(c.getString("crystal.mode", "crosshair"))) {
            crystalCrosshair(p, c, inMain);
            return;
        }

        // ---- Mode target (lama): hanya jalan kalau ada target di dekat ----
        double targetRange = c.getDouble("crystal.target-range", 8.0);
        double maxDist = c.getDouble("crystal.obsidian-max-distance", 2.0);
        double placeReach = c.getDouble("crystal.place-reach", 4.5);
        double breakReach = c.getDouble("crystal.break-reach", 4.5);
        double minSelf = c.getDouble("crystal.min-self-distance", 0.0);
        boolean instant = c.getBoolean("crystal.instant-break", true);

        List<LivingEntity> targets = findTargets(p, targetRange,
                c.getBoolean("crystal.hit-mobs", true),
                c.getBoolean("crystal.ignore-creative-spectator", true));
        if (targets.isEmpty()) return;

        Location eye = p.getEyeLocation();

        // 1) Ledakkan crystal yang sudah ada di dekat target
        for (LivingEntity t : targets) {
            for (Entity e : t.getNearbyEntities(maxDist + 3, maxDist + 3, maxDist + 3)) {
                if (!(e instanceof EnderCrystal crystal)) continue;
                double dist = crystal.getLocation().distance(eye);
                if (dist <= breakReach && dist >= minSelf) {
                    p.attack(crystal);
                    p.swingMainHand();
                    markCrystal(p);
                    return;
                }
            }
        }

        // 2) Cari base dekat target, pilih yang paling dekat
        Block bestBase = null;
        double bestDist = Double.MAX_VALUE;
        int radius = (int) Math.ceil(maxDist);

        for (LivingEntity t : targets) {
            Location tl = t.getLocation();
            Block feet = tl.getBlock();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    for (int dy = -radius - 1; dy <= radius; dy++) {
                        Block base = feet.getRelative(dx, dy, dz);
                        if (!crystalBases.contains(base.getType())) continue;
                        if (!base.getRelative(0, 1, 0).isEmpty()) continue;

                        Location spot = base.getLocation().add(0.5, 1.0, 0.5);

                        double distTarget = spot.distance(tl);
                        if (distTarget > maxDist) continue;

                        double distPlayer = spot.distance(eye);
                        if (distPlayer > placeReach || distPlayer < minSelf) continue;

                        if (spotBlocked(spot)) continue;

                        if (distTarget < bestDist) {
                            bestDist = distTarget;
                            bestBase = base;
                        }
                    }
                }
            }
        }

        if (bestBase == null) return;

        // 3) Pasang crystal (diledakkan di aksi berikutnya, atau langsung kalau instant-break)
        Location spawnLoc = bestBase.getLocation().add(0.5, 1.0, 0.5);
        EnderCrystal placed = bestBase.getWorld().spawn(spawnLoc, EnderCrystal.class,
                cr -> cr.setShowingBottom(false));
        consumeCrystal(p, inMain);
        p.swingMainHand();
        if (instant) p.attack(placed);
        markCrystal(p);
    }

    /**
     * Crosshair mode: arahkan crosshair ke obsidian/bedrock -> crystal langsung dipasang dan diledakkan.
     * Arahkan crosshair ke crystal -> langsung diledakkan. Tidak perlu ada target di dekat.
     * Layar tidak pernah digerakkan.
     */
    private void crystalCrosshair(Player p, FileConfiguration c, boolean inMain) {
        double placeReach = c.getDouble("crystal.place-reach", 4.5);
        double breakReach = c.getDouble("crystal.break-reach", 4.5);
        double minSelf = c.getDouble("crystal.min-self-distance", 0.0);
        boolean instant = c.getBoolean("crystal.instant-break", true);

        Location eye = p.getEyeLocation();
        Vector start = eye.toVector();
        RayTraceResult blockHit = p.rayTraceBlocks(Math.max(placeReach, breakReach));
        double blockDist = blockHit == null ? Double.MAX_VALUE : blockHit.getHitPosition().distance(start);

        // 1) Crystal tepat di crosshair -> ledakkan
        RayTraceResult ent = p.getWorld().rayTraceEntities(eye, eye.getDirection(), breakReach, 0.3,
                e -> e instanceof EnderCrystal);
        if (ent != null && ent.getHitEntity() instanceof EnderCrystal crystal) {
            double d = ent.getHitPosition().distance(start);
            if (d <= blockDist + 0.5 && crystal.getLocation().distance(eye) >= minSelf) {
                p.attack(crystal);
                p.swingMainHand();
                markCrystal(p);
                return;
            }
        }

        // 2) Obsidian/bedrock di crosshair -> pasang crystal
        if (blockHit == null || blockHit.getHitBlock() == null) return;
        Block base = blockHit.getHitBlock();
        if (!crystalBases.contains(base.getType())) return;
        if (!base.getRelative(0, 1, 0).isEmpty()) return;

        Location spot = base.getLocation().add(0.5, 1.0, 0.5);
        double dist = spot.distance(eye);
        if (dist > placeReach || dist < minSelf) return;
        if (spotBlocked(spot)) return;

        EnderCrystal placed = base.getWorld().spawn(spot, EnderCrystal.class, cr -> cr.setShowingBottom(false));
        consumeCrystal(p, inMain);
        p.swingMainHand();
        if (instant) p.attack(placed);
        markCrystal(p);
    }

    /** Catat aksi crystal; jitter acak kecil supaya ritmenya tidak kaku. */
    private void markCrystal(Player p) {
        int jitter = Math.max(0, getConfig().getInt("crystal.delay-jitter", 1));
        long extra = jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0;
        lastCrystalAction.put(p.getUniqueId(), tickCounter + extra);
    }

    private void consumeCrystal(Player p, boolean inMain) {
        if (p.getGameMode() == GameMode.CREATIVE) return;
        PlayerInventory inv = p.getInventory();
        if (inMain) {
            ItemStack it = inv.getItemInMainHand();
            it.setAmount(it.getAmount() - 1);
            inv.setItemInMainHand(it.getAmount() <= 0 ? null : it);
        } else {
            ItemStack it = inv.getItemInOffHand();
            it.setAmount(it.getAmount() - 1);
            inv.setItemInOffHand(it.getAmount() <= 0 ? null : it);
        }
    }

    // Ruang crystal (1x2x1 di atas base) tidak boleh ditempati makhluk lain / crystal lain
    private boolean spotBlocked(Location spot) {
        for (Entity e : spot.getWorld().getNearbyEntities(spot.clone().add(0, 1.0, 0), 0.5, 1.0, 0.5)) {
            if (e instanceof LivingEntity || e instanceof EnderCrystal) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // AUTO MACE
    // - kill aura: pemain dalam jarak dekat kena walau di belakang, crosshair agak meleset tetap kena
    // - kamera (opsional, default mati): mengikuti target saat masih tinggi
    // - posisi dan kecepatan jatuh tidak pernah diubah
    // ------------------------------------------------------------------

    private void doMace(Player p) {
        FileConfiguration c = getConfig();
        UUID id = p.getUniqueId();
        MaceState st = maceStates.computeIfAbsent(id, k -> new MaceState());

        // Terbang dengan elytra: kalau sudah dekat/di atas kepala lawan -> ganti ke mace dan pukul sekali
        if (p.isGliding() && c.getBoolean("mace.elytra-mode", true)) {
            doMaceElytra(p, st, c);
            return;
        }

        boolean falling = !p.isOnGround() && !p.isGliding()
                && p.getFallDistance() >= c.getDouble("mace.min-fall-distance", 1.5);
        boolean onlyFalling = c.getBoolean("mace.only-while-falling", true);

        if (!falling) {
            st.lock = null;
            st.engageTick = -1;
            st.rotations = 0;
            st.vYaw = 0;
            st.vPitch = 0;
            if (onlyFalling) return;
        }

        PlayerInventory inv = p.getInventory();
        if (inv.getItemInMainHand().getType() != Material.MACE) {
            if (!c.getBoolean("mace.auto-switch", false)) return;
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack it = inv.getItem(i);
                if (it != null && it.getType() == Material.MACE) {
                    slot = i;
                    break;
                }
            }
            if (slot == -1) return;
            inv.setHeldItemSlot(slot);
        }

        boolean hitMobs = c.getBoolean("mace.hit-mobs", true);

        // 1) Kamera (default MATI). Kalau dinyalakan: hanya aktif saat masih tinggi di atas target.
        if (falling && c.getBoolean("mace.camera", false)) {
            LivingEntity lock = getLock(p, st, c.getDouble("mace.aim-range", 8.0),
                    c.getDouble("mace.aim-vertical", 25.0), c.getDouble("mace.aim-fov", 120.0), hitMobs);
            if (lock != null) {
                if (st.engageTick < 0) {
                    int rt = Math.max(0, c.getInt("mace.reaction-ticks", 4));
                    st.engageTick = tickCounter + rt + (rt > 0 ? ThreadLocalRandom.current().nextInt(3) : 0);
                }
                if (tickCounter >= st.engageTick) {
                    aimAt(p, st, lock, cameraAllowed(p, st, lock, c), aimParams(p, c, "mace."));
                }
            }
        }

        // 2) Pukul otomatis
        if (!c.getBoolean("mace.auto-attack", true)) return;
        if (tickCounter < st.nextAttack) return;

        double reach = c.getDouble("mace.reach", 3.1);
        LivingEntity victim = null;
        // a) Kill aura jarak dekat: siapa pun dalam killaura-reach kena, walau di belakang kita
        double killReach = c.getDouble("mace.killaura-reach", 2.0);
        if (killReach > 0) victim = nearestInReach(p, killReach, hitMobs);
        // b) Crosshair agak meleset: target dalam jangkauan dan masih dalam sudut assist-angle
        if (victim == null) victim = coneTarget(p, reach, c.getDouble("mace.assist-angle", 40.0), hitMobs);
        // c) Tepat di crosshair (toleransi hitbox)
        if (victim == null) victim = facingTarget(p, reach, hitMobs);
        if (victim == null) return;

        p.attack(victim);
        p.swingMainHand();

        long interval = c.getLong("mace.attack-interval", 34);
        int jitter = Math.max(0, c.getInt("mace.attack-jitter", 3));
        st.nextAttack = tickCounter + interval + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
        st.lock = null;
        st.engageTick = -1;
        st.rotations = 0;
    }

    /** Mode elytra: lawan 1-2 blok di bawah/di atas kepala atau menempel -> ganti ke mace, pukul SEKALI. */
    private void doMaceElytra(Player p, MaceState st, FileConfiguration c) {
        if (tickCounter < st.nextAttack) return;
        boolean hitMobs = c.getBoolean("mace.hit-mobs", true);
        double horiz = c.getDouble("mace.elytra-horizontal", 1.8);
        double above = c.getDouble("mace.elytra-above", 2.5);
        double below = c.getDouble("mace.elytra-below", 2.0);

        Location pl = p.getLocation();
        LivingEntity victim = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(pl, horiz + 1, above + below + 4, horiz + 1)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            Location tl = le.getLocation();
            double h = Math.hypot(tl.getX() - pl.getX(), tl.getZ() - pl.getZ());
            if (h > horiz) continue;
            double dy = pl.getY() - (tl.getY() + le.getHeight());   // tinggi kita di atas kepala target
            if (dy > above || dy < -below) continue;
            double d = h * h + dy * dy;
            if (d < bestDist) {
                bestDist = d;
                victim = le;
            }
        }
        if (victim == null) return;

        PlayerInventory inv = p.getInventory();
        if (inv.getItemInMainHand().getType() != Material.MACE) {
            if (!c.getBoolean("mace.elytra-switch", true)) return;
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack it = inv.getItem(i);
                if (it != null && it.getType() == Material.MACE) {
                    slot = i;
                    break;
                }
            }
            if (slot == -1) return;
            inv.setHeldItemSlot(slot);
        }

        p.attack(victim);
        p.swingMainHand();
        long interval = c.getLong("mace.attack-interval", 34);
        int jitter = Math.max(0, c.getInt("mace.attack-jitter", 3));
        st.nextAttack = tickCounter + interval + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
    }

    /**
     * Kapan kamera TIDAK boleh disentuh sama sekali.
     * Kamera hanya bekerja saat masih tinggi di atas target; di dekat target tidak ada gerakan kamera.
     */
    private boolean cameraAllowed(Player p, MaceState st, LivingEntity target, FileConfiguration c) {
        Location pl = p.getLocation();
        Location tl = target.getLocation();
        double heightAbove = pl.getY() - tl.getY();
        if (heightAbove <= c.getDouble("mace.camera-off-height", 4.0)) return false;
        double horizontal = Math.hypot(tl.getX() - pl.getX(), tl.getZ() - pl.getZ());
        if (horizontal < c.getDouble("mace.min-horizontal", 1.5)) return false;      // hampir tepat di atas
        double dist = center(target).distance(p.getEyeLocation());
        if (dist <= c.getDouble("mace.stop-camera-within", 4.0)) return false;       // sudah dekat
        int max = c.getInt("mace.max-rotations", 0);
        if (max > 0 && st.rotations >= max) return false;                            // batas per jatuhan
        return true;
    }

    /** Target terdekat dalam jangkauan yang masih dalam sudut tertentu dari arah pandang (crosshair agak meleset). */
    private LivingEntity coneTarget(Player p, double reach, double angle, boolean hitMobs) {
        if (angle <= 0) return null;
        Location eye = p.getEyeLocation();
        Vector look = eye.getDirection();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(eye, reach + 2)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            Vector to = center(le).toVector().subtract(eye.toVector());
            double d = to.length();
            if (d > reach || d < 1.0E-6) continue;
            if (Math.toDegrees(look.angle(to)) > angle) continue;
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    /** Target yang benar-benar tepat di crosshair (ray dari mata ke hitbox, dengan toleransi). */
    private LivingEntity facingTarget(Player p, double reach, boolean hitMobs) {
        Location eye = p.getEyeLocation();
        Vector start = eye.toVector();
        Vector dir = eye.getDirection();
        double expand = getConfig().getDouble("mace.hit-expand", 0.25);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(eye, reach + 2)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            RayTraceResult r = le.getBoundingBox().clone().expand(expand).rayTrace(start, dir, reach);
            if (r == null) continue;
            double d = r.getHitPosition().distance(start);
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    /** Target terdekat dalam jarak tertentu dari mata, ke arah mana pun (kill aura). */
    private LivingEntity nearestInReach(Player p, double reach, boolean hitMobs) {
        Location eye = p.getEyeLocation();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), reach + 2)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            double d = center(le).distance(eye);
            if (d <= reach && d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    // Target kunci dipertahankan selama masih valid, supaya kamera tidak berpindah-pindah
    private LivingEntity getLock(Player p, MaceState st, double range, double vertical, double fov, boolean hitMobs) {
        if (st.lock != null) {
            Entity e = Bukkit.getEntity(st.lock);
            if (e instanceof LivingEntity le && validLock(p, le, range, vertical, hitMobs)) return le;
            st.lock = null;
            st.engageTick = -1;
        }

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        Location eye = p.getEyeLocation();
        Vector look = eye.getDirection();
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), range, vertical, range)) {
            if (!validLock(p, le, range, vertical, hitMobs)) continue;
            Vector to = center(le).toVector().subtract(eye.toVector());
            if (to.lengthSquared() < 1.0E-6) continue;
            if (Math.toDegrees(look.angle(to)) > fov) continue;
            double d = to.length();
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        if (best != null) st.lock = best.getUniqueId();
        return best;
    }

    private boolean validLock(Player p, LivingEntity le, double range, double vertical, boolean hitMobs) {
        if (!isAttackable(p, le, hitMobs, true)) return false;
        if (!le.getWorld().equals(p.getWorld())) return false;
        Location pl = p.getLocation();
        Location tl = le.getLocation();
        if (tl.getY() > pl.getY() + 0.5) return false;          // hanya yang di bawah
        if (pl.getY() - tl.getY() > vertical) return false;
        return Math.hypot(tl.getX() - pl.getX(), tl.getZ() - pl.getZ()) <= range;
    }

    /** Pemain Bedrock (Floodgate): UUID berawalan 0, atau nama berawalan titik. */
    private boolean isBedrock(Player p) {
        return p.getUniqueId().getMostSignificantBits() == 0L
                || p.getName().startsWith(getConfig().getString("bedrock.prefix", "."));
    }

    /** Parameter kamera. Bagian config: sec ("mace." / "autohit."), Bedrock punya nilai sendiri. */
    private record AimParams(int interval, float maxTurn, float deadzone, float smoothing, float accel,
                             double noise, float yawScale) {
    }

    private AimParams aimParams(Player p, FileConfiguration c, String sec) {
        boolean bedrock = isBedrock(p);
        String bs = sec.equals("mace.") ? "bedrock." : sec + "bedrock-";
        int interval = Math.max(1, bedrock ? c.getInt(bs + "rotation-interval", 3)
                : c.getInt(sec + "rotation-interval", 2));
        float maxTurn = (float) (bedrock ? c.getDouble(bs + "max-turn-speed", 2.5)
                : c.getDouble(sec + "max-turn-speed", 4.0));
        float yawScale = bedrock ? (float) Math.max(0.0, Math.min(1.0, c.getDouble(bs + "yaw-scale", 0.4))) : 1f;
        return new AimParams(interval, maxTurn,
                (float) c.getDouble(sec + "deadzone", 2.0),
                (float) Math.max(0.02, Math.min(1.0, c.getDouble(sec + "aim-smoothing", 0.12))),
                (float) Math.max(0.05, Math.min(1.0, c.getDouble(sec + "accel", 0.25))),
                Math.max(0.0, Math.min(0.9, c.getDouble(sec + "aim-noise", 0.25))),
                yawScale);
    }

    /**
     * Gerakkan kamera dengan kecepatan putar yang berubah pelan-pelan (bukan mulai/berhenti mendadak).
     * Posisi dan kecepatan gerak pemain tidak pernah diubah.
     */
    private void aimAt(Player p, MaceState st, LivingEntity target, boolean active, AimParams ap) {
        long since = tickCounter - st.lastRot;
        if (since < ap.interval()) return;
        float elapsed = Math.min(since, 4);
        st.lastRot = tickCounter;

        Location eye = p.getEyeLocation();
        float desYaw = 0f;
        float desPitch = 0f;

        boolean onTarget = target.getBoundingBox().clone().expand(0.05)
                .rayTrace(eye.toVector(), eye.getDirection(), 16.0) != null;

        if (active && !onTarget) {
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            if (tickCounter >= st.noiseUntil) {
                st.nx = rnd.nextDouble(-1, 1);
                st.ny = rnd.nextDouble(-1, 1);
                st.nz = rnd.nextDouble(-1, 1);
                st.noiseUntil = tickCounter + 8 + rnd.nextInt(9);
            }
            st.cx += (st.nx - st.cx) * 0.2;
            st.cy += (st.ny - st.cy) * 0.2;
            st.cz += (st.nz - st.cz) * 0.2;

            BoundingBox bb = target.getBoundingBox();
            double n = ap.noise();
            Vector aim = new Vector(
                    bb.getCenterX() + st.cx * (bb.getWidthX() / 2) * n,
                    bb.getCenterY() + st.cy * (bb.getHeight() / 2) * n,
                    bb.getCenterZ() + st.cz * (bb.getWidthZ() / 2) * n);

            Vector d = aim.subtract(eye.toVector());
            double horizontal = Math.hypot(d.getX(), d.getZ());
            float targetYaw = (float) Math.toDegrees(Math.atan2(-d.getX(), d.getZ()));
            float targetPitch = (float) Math.toDegrees(-Math.atan2(d.getY(), horizontal));

            float deltaYaw = horizontal < 0.35 ? 0f : wrap180(targetYaw - eye.getYaw());
            float deltaPitch = targetPitch - eye.getPitch();

            if (Math.abs(deltaYaw) >= ap.deadzone()) {
                desYaw = clamp(deltaYaw * ap.smoothing(), -ap.maxTurn(), ap.maxTurn()) * ap.yawScale();
            }
            if (Math.abs(deltaPitch) >= ap.deadzone()) {
                desPitch = clamp(deltaPitch * ap.smoothing(), -ap.maxTurn(), ap.maxTurn());
            }
        }

        st.vYaw += (desYaw - st.vYaw) * ap.accel();
        st.vPitch += (desPitch - st.vPitch) * ap.accel();

        // Terlalu kecil untuk berarti: jangan kirim paket rotasi sama sekali
        if (Math.abs(st.vYaw) < 0.05f && Math.abs(st.vPitch) < 0.05f) {
            st.vYaw = 0f;
            st.vPitch = 0f;
            return;
        }

        st.rotations++;
        p.setRotation(wrap180(eye.getYaw() + st.vYaw * elapsed),
                clamp(eye.getPitch() + st.vPitch * elapsed, -90f, 90f));
    }

    // ------------------------------------------------------------------
    // AUTO HIT (/autohit): seperti hit Java, satu klik per cooldown senjata, kamera mengikuti halus.
    // Aktif kalau ada target dalam jarak 1-2 blok.
    // ------------------------------------------------------------------

    private static double distToBox(Location eye, BoundingBox bb) {
        double dx = Math.max(Math.max(bb.getMinX() - eye.getX(), 0), eye.getX() - bb.getMaxX());
        double dy = Math.max(Math.max(bb.getMinY() - eye.getY(), 0), eye.getY() - bb.getMaxY());
        double dz = Math.max(Math.max(bb.getMinZ() - eye.getZ(), 0), eye.getZ() - bb.getMaxZ());
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private long hitInterval(ItemStack it, FileConfiguration c) {
        String n = it == null ? "" : it.getType().name();
        if (n.equals("MACE")) return c.getLong("autohit.interval-mace", 34);
        if (n.endsWith("_AXE")) return c.getLong("autohit.interval-axe", 22);
        if (n.endsWith("_SPEAR")) return c.getLong("autohit.interval-spear", 16);
        return c.getLong("autohit.interval", 13);
    }

    private void doAutoHit(Player p) {
        FileConfiguration c = getConfig();
        UUID id = p.getUniqueId();
        MaceState st = hitStates.computeIfAbsent(id, k -> new MaceState());
        boolean hitMobs = c.getBoolean("autohit.hit-mobs", true);
        double range = c.getDouble("autohit.range", 2.0);
        Location eye = p.getEyeLocation();

        // Pertahankan target yang sama supaya kamera tidak berpindah-pindah
        LivingEntity target = null;
        if (st.lock != null) {
            Entity e = Bukkit.getEntity(st.lock);
            if (e instanceof LivingEntity le && isAttackable(p, le, hitMobs, true)
                    && le.getWorld().equals(p.getWorld())
                    && distToBox(eye, le.getBoundingBox()) <= range + 0.5) {
                target = le;
            } else {
                st.lock = null;
            }
        }
        if (target == null) {
            double bestDist = Double.MAX_VALUE;
            for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), range + 2)) {
                if (!isAttackable(p, le, hitMobs, true)) continue;
                double d = distToBox(eye, le.getBoundingBox());
                if (d <= range && d < bestDist) {
                    bestDist = d;
                    target = le;
                }
            }
            if (target != null) st.lock = target.getUniqueId();
        }

        if (target == null) {
            st.vYaw = 0f;
            st.vPitch = 0f;
            return;
        }

        // Kamera halus mengikuti target
        if (c.getBoolean("autohit.camera", true)) {
            aimAt(p, st, target, true, aimParams(p, c, "autohit."));
        }

        // Satu klik per cooldown, hanya kalau sudah cukup menghadap target
        if (tickCounter < st.nextAttack) return;
        Vector to = center(target).toVector().subtract(eye.toVector());
        if (to.lengthSquared() > 1.0E-6
                && Math.toDegrees(eye.getDirection().angle(to)) > c.getDouble("autohit.attack-angle", 60.0)) {
            return;
        }

        p.attack(target);
        p.swingMainHand();
        long interval = hitInterval(p.getInventory().getItemInMainHand(), c);
        int jitter = Math.max(0, c.getInt("autohit.interval-jitter", 2));
        st.nextAttack = tickCounter + interval + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
    }

    // ------------------------------------------------------------------
    // AUTO ENDER PEARL + WIND CHARGE (/autopearl)
    // Saat kamu melempar ender pearl (klik kanan / tekan), wind charge otomatis dilempar sesaat
    // kemudian. Ada cooldown supaya tidak bisa di-spam. Wind charge diambil dari inventory.
    // ------------------------------------------------------------------

    @EventHandler(ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent e) {
        if (!(e.getEntity() instanceof EnderPearl)) return;
        if (!(e.getEntity().getShooter() instanceof Player p)) return;
        UUID id = p.getUniqueId();
        if (!pearlOn.contains(id) || !p.isOp() || !canAct(p)) return;

        FileConfiguration c = getConfig();
        long cd = c.getLong("pearl.cooldown", 40);
        if (tickCounter - lastPearlCombo.getOrDefault(id, -1000L) < cd) return;
        lastPearlCombo.put(id, tickCounter);

        // Arah wind charge: mengikuti arah lemparan ender pearl (default), atau arah pandang / ke bawah
        String mode = c.getString("pearl.wind-direction", "pearl");
        Vector dir;
        if ("down".equalsIgnoreCase(mode)) {
            dir = new Vector(0, -1, 0);
        } else if ("look".equalsIgnoreCase(mode)) {
            dir = p.getEyeLocation().getDirection();
        } else {
            dir = e.getEntity().getVelocity().clone();
            if (dir.lengthSquared() < 1.0E-6) dir = p.getEyeLocation().getDirection();
        }
        final Vector windDir = dir.normalize();

        int delay = Math.max(0, c.getInt("pearl.wind-delay", 1));
        int jitter = Math.max(0, c.getInt("pearl.delay-jitter", 1));
        long wait = delay + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
        if (wait <= 0) {
            throwWindCharge(p, windDir);
        } else {
            Bukkit.getScheduler().runTaskLater(this, () -> throwWindCharge(p, windDir), wait);
        }
    }

    private void throwWindCharge(Player p, Vector dir) {
        if (!p.isOnline() || p.isDead()) return;
        PlayerInventory inv = p.getInventory();
        int slot = -1;
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (it != null && it.getType() == Material.WIND_CHARGE) {
                slot = i;
                break;
            }
        }
        boolean creative = p.getGameMode() == GameMode.CREATIVE;
        if (slot == -1 && !creative) return;

        p.launchProjectile(WindCharge.class, dir.clone().multiply(getConfig().getDouble("pearl.wind-speed", 1.5)));

        if (!creative) {
            ItemStack it = inv.getItem(slot);
            if (it != null) {
                it.setAmount(it.getAmount() - 1);
                inv.setItem(slot, it.getAmount() <= 0 ? null : it);
            }
        }
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float wrap180(float a) {
        a %= 360f;
        if (a >= 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    // ------------------------------------------------------------------
    // AUTO SPEAR (hanya saat spear dipegang)
    // Pukul otomatis secepat pemain laptop, lalu (opsional) pindah ke slot spear di sebelahnya.
    // Gerakan, lompat, dan dash TIDAK diubah plugin (tetap vanila). Kamera tidak digerakkan.
    // ------------------------------------------------------------------

    private static boolean isSpear(ItemStack it) {
        return it != null && it.getType().name().endsWith("_SPEAR");
    }

    private void doSpear(Player p) {
        if (!isSpear(p.getInventory().getItemInMainHand())) return;

        FileConfiguration c = getConfig();
        UUID id = p.getUniqueId();
        long interval = c.getLong("spear.attack-interval", 3);
        if (tickCounter - lastSpearAttack.getOrDefault(id, -1000L) < interval) return;

        boolean hitMobs = c.getBoolean("spear.hit-mobs", true);
        double reach = c.getDouble("spear.reach", 3.0);

        // Murni otomatisasi pukulan: gerakan, lompat, dan dash tetap dari pemain / vanila (lunge)
        LivingEntity victim = facingTarget(p, reach, hitMobs);
        if (victim == null) victim = coneTarget(p, reach, c.getDouble("spear.assist-angle", 25.0), hitMobs);
        if (victim == null) return;

        p.attack(victim);
        p.swingMainHand();

        int jitter = Math.max(0, c.getInt("spear.attack-jitter", 2));
        long last = tickCounter + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
        if (c.getBoolean("spear.auto-switch", true) && nextSpearSlot(p)) {
            last = tickCounter - interval + Math.max(0, c.getLong("spear.switch-delay", 2));
        }
        lastSpearAttack.put(id, last);
    }

    /** Pindah ke slot hotbar berikutnya yang berisi spear (berputar). true kalau berpindah. */
    private boolean nextSpearSlot(Player p) {
        PlayerInventory inv = p.getInventory();
        int cur = inv.getHeldItemSlot();
        for (int i = 1; i < 9; i++) {
            int slot = (cur + i) % 9;
            if (isSpear(inv.getItem(slot))) {
                inv.setHeldItemSlot(slot);
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // COMMANDS (senyap: tidak ada pesan chat)
    // ------------------------------------------------------------------

    /** Senyap total: tidak ada pesan chat/action bar. Hanya dicatat di log server (console), tidak terlihat pemain. */
    private void toggle(Player p, Set<UUID> set, String name, String arg) {
        UUID id = p.getUniqueId();
        boolean enable = arg == null ? !set.contains(id) : arg.equalsIgnoreCase("on");
        if (enable) set.add(id); else set.remove(id);
        maceStates.remove(id);
        hitStates.remove(id);
    }

    /**
     * Tidak ada command terdaftar di plugin.yml sama sekali: command di bawah ini TIDAK muncul di
     * tab-complete maupun /help siapa pun (termasuk operator), dan untuk pemain biasa terlihat
     * persis seperti command yang tidak ada ("Unknown command"). Hanya operator (isOp()) yang
     * perintahnya benar-benar dieksekusi di sini, dan dijalankan SENYAP: tanpa balasan chat/action
     * bar apa pun, baik berhasil maupun ditolak.
     */
    @EventHandler(priority = org.bukkit.event.EventPriority.LOWEST, ignoreCancelled = true)
    public void onPreprocess(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!p.isOp()) return; // bukan operator: biarkan lewat apa adanya (server akan bilang "Unknown command")

        String raw = e.getMessage().substring(1); // buang "/"
        String[] parts = raw.split("\\s+");
        String label = parts[0].toLowerCase();
        String arg = (parts.length > 1 && (parts[1].equalsIgnoreCase("on") || parts[1].equalsIgnoreCase("off")))
                ? parts[1] : null;

        Set<UUID> target;
        switch (label) {
            case "autoendcrystal", "autocrystal", "aec", "endcrystal" -> target = crystalOn;
            case "automace", "am" -> target = maceOn;
            case "autospear", "spear" -> target = spearOn;
            case "autopearl", "apearl" -> target = pearlOn;
            case "autohit", "ah" -> target = hitOn;
            default -> target = null;
        }
        if (target == null) return; // bukan salah satu command kita: biarkan lewat normal

        toggle(p, target, label, arg);
        e.setCancelled(true); // cegah "Unknown command" muncul ke operator, tanpa balasan apa pun
    }

}
