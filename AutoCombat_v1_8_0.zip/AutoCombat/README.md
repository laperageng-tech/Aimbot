# AutoCombat v1.8.0

Plugin Paper 1.21.11 (Java 21), server-side. Jalan untuk pemain **Java** dan **Bedrock (Geyser/Floodgate)**.

## Fitur

- **Auto End Crystal** (`/autoendcrystal`, alias `/autocrystal`, `/aec`, `/endcrystal`): arahkan crosshair ke obsidian/bedrock -> crystal langsung dipasang dan diledakkan tiap tick. Crosshair ke crystal -> langsung diledakkan. Layar tidak digerakkan.
- **Auto Mace** (`/automace`, alias `/am`): kill aura jarak dekat (`mace.killaura-reach`, arah mana pun termasuk di belakang) + assist crosshair meleset (`mace.assist-angle`). Kamera mati secara default (`mace.camera: false`). Posisi dan kecepatan jatuh tidak diubah.
- **Auto Spear** (`/autospear`, alias `/spear`): hanya saat spear dipegang. Pukul otomatis secepat pemain laptop (gerakan tetap vanila), lalu otomatis pindah ke slot spear di sebelahnya dan ulangi. Kamera tidak disentuh. Taruh beberapa spear berdampingan di hotbar.
- **Auto Pearl + Wind Charge** (`/autopearl`, alias `/apearl`): saat melempar ender pearl, wind charge otomatis dilempar sesaat kemudian (searah lemparan ender pearl). Ada cooldown 2 detik supaya tidak bisa di-spam. Wind charge diambil dari inventory.
- **Auto Hit** (`/autohit`, alias `/ah`): kalau ada target dalam 2 blok, memukul satu kali per cooldown senjata (ritme Java) dan kamera mengikuti target dengan halus.

## Build

JDK 21 + Maven: `mvn package` -> `target/AutoCombat.jar`. Atau dorong ke GitHub, workflow `build-autocombat.yml` akan membangunnya.
Hapus `plugins/AutoCombat/config.yml` lama sebelum restart supaya config baru dibuat.

## Akses: khusus operator, tanpa verifikasi, dan tersembunyi

Tidak ada sistem verifikasi lagi. Tidak satu pun command didaftarkan ke server (tidak ada di
`plugin.yml`), jadi:

- Tidak muncul di tab-complete atau `/help` siapa pun, termasuk operator sendiri.
- Untuk pemain biasa (bukan OP), mengetik `/automace on` dan sejenisnya terlihat persis seperti
  command yang tidak ada (server membalas "Unknown command"), dan tidak berbuat apa-apa.
- Untuk **operator (OP)** server, command yang sama langsung aktif di baliknya, tanpa pesan chat
  atau action bar apa pun -- baik saat ON maupun OFF, suksek atau tidak, semuanya senyap.
- Begitu status OP seorang pemain dicabut, semua togglenya otomatis ikut mati.

Tidak ada file `allowed.yml` atau daftar nama lagi. Satu-satunya syarat akses adalah status
operator bawaan server (`/op <nama>` di console atau dari pemain OP lain).

## Keamanan

Plugin tidak mengubah pengaturan server apa pun di luar togglenya sendiri. Karena akses murni
berdasarkan status OP, jaga daftar operator server supaya hanya berisi orang yang kamu percaya.
