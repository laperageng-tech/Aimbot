package id.zentra.autocombat;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class AutoCombat extends JavaPlugin implements CommandExecutor, Listener {

    private final Set<UUID> crystalOn = new HashSet<>();
    private final Set<UUID> maceOn = new HashSet<>();
    private final Set<UUID> allowed = new HashSet<>();
    private final Map<UUID, Long> lastCrystalAction = new HashMap<>();
    private final Map<UUID, Long> lastMaceAttack = new HashMap<>();
    private final Map<UUID, UUID> maceLock = new HashMap<>();
    private long tickCounter = 0;
    private File allowedFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        allowedFile = new File(getDataFolder(), "allowed.yml");
        loadAllowed();
        getCommand("aimbot").setExecutor(this);
        getCommand("autocrystal").setExecutor(this);
        getCommand("automace").setExecutor(this);
        getCommand("autocombat").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        startTask();
    }

    @Override
    public void onDisable() {
        Bukkit.getScheduler().cancelTasks(this);
        crystalOn.clear();
        maceOn.clear();
        lastCrystalAction.clear();
        lastMaceAttack.clear();
        maceLock.clear();
    }

    private void startTask() {
        Bukkit.getScheduler().cancelTasks(this);
        long interval = Math.max(1, getConfig().getLong("tick-interval", 1));
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            tickCounter += interval;
            for (UUID id : new HashSet<>(crystalOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && canAct(p)) doCrystal(p);
            }
            for (UUID id : new HashSet<>(maceOn)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && allowed.contains(id) && canAct(p)) doMace(p);
            }
        }, interval, interval);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        clearState(e.getPlayer().getUniqueId());
    }

    private void clearState(UUID id) {
        crystalOn.remove(id);
        maceOn.remove(id);
        lastCrystalAction.remove(id);
        lastMaceAttack.remove(id);
        maceLock.remove(id);
    }

    private boolean canAct(Player p) {
        if (!p.isOnline() || p.isDead()) return false;
        GameMode gm = p.getGameMode();
        return gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE || gm == GameMode.CREATIVE;
    }

    // ------------------------------------------------------------------
    // UMUM
    // ------------------------------------------------------------------

    private boolean isAttackable(Player self, LivingEntity le, boolean hitMobs, boolean ignoreCreative) {
        if (le.equals(self) || le.isDead() || !le.isValid() || le instanceof ArmorStand) return false;
        if (le instanceof Player other) {
            GameMode gm = other.getGameMode();
            if (gm == GameMode.SPECTATOR) return false;
            return !(ignoreCreative && gm == GameMode.CREATIVE);
        }
        return hitMobs;
    }

    private Location center(LivingEntity le) {
        return le.getLocation().add(0, le.getHeight() / 2, 0);
    }

    private List<LivingEntity> findTargets(Player self, double range, boolean hitMobs, boolean ignoreCreative) {
        List<LivingEntity> list = new ArrayList<>();
        for (LivingEntity le : self.getWorld().getNearbyLivingEntities(self.getLocation(), range)) {
            if (isAttackable(self, le, hitMobs, ignoreCreative)) list.add(le);
        }
        final Location origin = self.getLocation();
        list.sort(Comparator.comparingDouble((LivingEntity e) -> e.getLocation().distanceSquared(origin)));
        return list;
    }

    // ------------------------------------------------------------------
    // AUTO END CRYSTAL
    // Hanya saat crystal dipegang. TIDAK menggerakkan layar sama sekali.
    // ------------------------------------------------------------------

    private void doCrystal(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack mainHand = inv.getItemInMainHand();
        ItemStack offHand = inv.getItemInOffHand();
        boolean inMain = mainHand.getType() == Material.END_CRYSTAL;
        boolean inOff = offHand.getType() == Material.END_CRYSTAL;
        if (!inMain && !inOff) return;

        FileConfiguration c = getConfig();
        long delay = c.getLong("crystal.action-delay", 1);
        long last = lastCrystalAction.getOrDefault(p.getUniqueId(), -1000L);
        if (tickCounter - last < delay) return;

        double targetRange = c.getDouble("crystal.target-range", 8.0);
        double maxDist = c.getDouble("crystal.obsidian-max-distance", 2.0);
        double placeReach = c.getDouble("crystal.place-reach", 4.5);
        double breakReach = c.getDouble("crystal.break-reach", 4.5);
        double minSelf = c.getDouble("crystal.min-self-distance", 0.0);
        boolean instant = c.getBoolean("crystal.instant-break", true);

        List<LivingEntity> targets = findTargets(p, targetRange,
                c.getBoolean("crystal.hit-mobs", false),
                c.getBoolean("crystal.ignore-creative-spectator", true));
        if (targets.isEmpty()) return;

        Location eye = p.getEyeLocation();

        // 1) Ledakkan crystal yang sudah ada di dekat target
        for (LivingEntity t : targets) {
            for (Entity e : t.getNearbyEntities(maxDist + 3, maxDist + 3, maxDist + 3)) {
                if (!(e instanceof EnderCrystal crystal)) continue;
                double dist = crystal.getLocation().distance(eye);
                if (dist <= breakReach && dist >= minSelf) {
                    p.attack(crystal);
                    p.swingMainHand();
                    lastCrystalAction.put(p.getUniqueId(), tickCounter);
                    return;
                }
            }
        }

        // 2) Cari obsidian/bedrock maksimal maxDist dari target, pilih yang paling dekat
        Block bestBase = null;
        double bestDist = Double.MAX_VALUE;
        int radius = (int) Math.ceil(maxDist);

        for (LivingEntity t : targets) {
            Location tl = t.getLocation();
            Block feet = tl.getBlock();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    for (int dy = -radius - 1; dy <= radius; dy++) {
                        Block base = feet.getRelative(dx, dy, dz);
                        Material m = base.getType();
                        if (m != Material.OBSIDIAN && m != Material.BEDROCK) continue;
                        if (!base.getRelative(0, 1, 0).isEmpty()) continue;

                        Location spot = base.getLocation().add(0.5, 1.0, 0.5);

                        double distTarget = spot.distance(tl);
                        if (distTarget > maxDist) continue;

                        double distPlayer = spot.distance(eye);
                        if (distPlayer > placeReach || distPlayer < minSelf) continue;

                        if (spotBlocked(spot)) continue;

                        if (distTarget < bestDist) {
                            bestDist = distTarget;
                            bestBase = base;
                        }
                    }
                }
            }
        }

        if (bestBase == null) return;

        // 3) Pasang crystal, lalu langsung ledakkan
        Location spawnLoc = bestBase.getLocation().add(0.5, 1.0, 0.5);
        EnderCrystal placed = bestBase.getWorld().spawn(spawnLoc, EnderCrystal.class,
                cr -> cr.setShowingBottom(false));

        if (p.getGameMode() != GameMode.CREATIVE) {
            if (inMain) {
                mainHand.setAmount(mainHand.getAmount() - 1);
                inv.setItemInMainHand(mainHand.getAmount() <= 0 ? null : mainHand);
            } else {
                offHand.setAmount(offHand.getAmount() - 1);
                inv.setItemInOffHand(offHand.getAmount() <= 0 ? null : offHand);
            }
        }

        p.swingMainHand();
        if (instant) p.attack(placed);
        lastCrystalAction.put(p.getUniqueId(), tickCounter);
    }

    // Ruang crystal (1x2x1 di atas obsidian) tidak boleh ditempati makhluk lain / crystal lain
    private boolean spotBlocked(Location spot) {
        for (Entity e : spot.getWorld().getNearbyEntities(spot.clone().add(0, 1.0, 0), 0.5, 1.0, 0.5)) {
            if (e instanceof LivingEntity || e instanceof EnderCrystal) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // AUTO MACE
    // - layar mengunci target di bawah dengan halus saat jatuh (kamera saja)
    // - kill aura: pukul target terdekat dalam jangkauan
    // ------------------------------------------------------------------

    private void doMace(Player p) {
        FileConfiguration c = getConfig();
        UUID id = p.getUniqueId();

        boolean falling = !p.isOnGround() && !p.isGliding()
                && p.getFallDistance() >= c.getDouble("mace.min-fall-distance", 1.5);
        boolean onlyFalling = c.getBoolean("mace.only-while-falling", true);

        if (!falling) {
            maceLock.remove(id);
            if (onlyFalling) return;
        }

        PlayerInventory inv = p.getInventory();
        if (inv.getItemInMainHand().getType() != Material.MACE) {
            if (!c.getBoolean("mace.auto-switch", false)) return;
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack it = inv.getItem(i);
                if (it != null && it.getType() == Material.MACE) {
                    slot = i;
                    break;
                }
            }
            if (slot == -1) return;
            inv.setHeldItemSlot(slot);
        }

        boolean hitMobs = c.getBoolean("mace.hit-mobs", true);

        // 1) Kunci layar ke target di bawah (hanya kamera, posisi tidak diubah)
        LivingEntity lock = null;
        if (falling) {
            lock = getLock(p, c.getDouble("mace.aim-range", 8.0),
                    c.getDouble("mace.aim-vertical", 25.0), hitMobs);
            if (lock != null) {
                aimAt(p, lock, c.getDouble("mace.aim-smoothing", 0.2),
                        (float) c.getDouble("mace.max-turn-speed", 12.0));
            }
        }

        // 2) Pukul otomatis / kill aura
        if (!c.getBoolean("mace.auto-attack", true)) return;
        long interval = c.getLong("mace.attack-interval", 34);
        if (tickCounter - lastMaceAttack.getOrDefault(id, -1000L) < interval) return;

        LivingEntity victim;
        if (c.getBoolean("mace.killaura", true)) {
            victim = nearestInReach(p, c.getDouble("mace.killaura-reach", 4.0), hitMobs);
        } else {
            double reach = c.getDouble("mace.reach", 3.5);
            victim = (lock != null && center(lock).distance(p.getEyeLocation()) <= reach) ? lock : null;
        }
        if (victim == null) return;

        p.attack(victim);
        p.swingMainHand();
        lastMaceAttack.put(id, tickCounter);
    }

    private LivingEntity nearestInReach(Player p, double reach, boolean hitMobs) {
        Location eye = p.getEyeLocation();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), reach + 2)) {
            if (!isAttackable(p, le, hitMobs, true)) continue;
            double d = center(le).distance(eye);
            if (d <= reach && d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    // Target kunci dipertahankan selama masih valid, supaya layar tidak berpindah-pindah
    private LivingEntity getLock(Player p, double range, double vertical, boolean hitMobs) {
        UUID id = p.getUniqueId();
        UUID lockedId = maceLock.get(id);
        if (lockedId != null) {
            Entity e = Bukkit.getEntity(lockedId);
            if (e instanceof LivingEntity le && validLock(p, le, range, vertical, hitMobs)) return le;
            maceLock.remove(id);
        }

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        Location eye = p.getEyeLocation();
        for (LivingEntity le : p.getWorld().getNearbyLivingEntities(p.getLocation(), range, vertical, range)) {
            if (!validLock(p, le, range, vertical, hitMobs)) continue;
            double d = center(le).distance(eye);
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        if (best != null) maceLock.put(id, best.getUniqueId());
        return best;
    }

    private boolean validLock(Player p, LivingEntity le, double range, double vertical, boolean hitMobs) {
        if (!isAttackable(p, le, hitMobs, true)) return false;
        if (!le.getWorld().equals(p.getWorld())) return false;
        Location pl = p.getLocation();
        Location tl = le.getLocation();
        if (tl.getY() > pl.getY() + 0.5) return false;          // hanya yang di bawah
        if (pl.getY() - tl.getY() > vertical) return false;
        return Math.hypot(tl.getX() - pl.getX(), tl.getZ() - pl.getZ()) <= range;
    }

    // Putar layar menuju target dengan halus (easing + batas kecepatan putar per tick)
    private void aimAt(Player p, LivingEntity target, double smoothing, float maxTurn) {
        Location eye = p.getEyeLocation();
        Vector d = center(target).toVector().subtract(eye.toVector());

        double horizontal = Math.hypot(d.getX(), d.getZ());
        float targetYaw = (float) Math.toDegrees(Math.atan2(-d.getX(), d.getZ()));
        float targetPitch = (float) Math.toDegrees(-Math.atan2(d.getY(), horizontal));

        // Target tepat di bawah: arah horizontal tidak jelas, jangan putar yaw (hindari layar tersentak)
        float deltaYaw = horizontal < 0.35 ? 0f : wrap180(targetYaw - eye.getYaw());
        float deltaPitch = targetPitch - eye.getPitch();

        float s = (float) Math.max(0.02, Math.min(1.0, smoothing));
        float stepYaw = clamp(deltaYaw * s, -maxTurn, maxTurn);
        float stepPitch = clamp(deltaPitch * s, -maxTurn, maxTurn);

        p.setRotation(wrap180(eye.getYaw() + stepYaw), clamp(eye.getPitch() + stepPitch, -90f, 90f));
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float wrap180(float a) {
        a %= 360f;
        if (a >= 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    // ------------------------------------------------------------------
    // COMMANDS (senyap: tidak ada pesan chat)
    // ------------------------------------------------------------------

    private void feedback(Player p, String text) {
        if (!"actionbar".equalsIgnoreCase(getConfig().getString("feedback", "off"))) return;
        p.sendActionBar(Component.text(text));
    }

    private void toggle(Player p, Set<UUID> set, String name, String arg) {
        UUID id = p.getUniqueId();
        boolean enable = arg == null ? !set.contains(id) : arg.equalsIgnoreCase("on");
        if (enable) set.add(id); else set.remove(id);
        feedback(p, name + (enable ? " ON" : " OFF"));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();

        // Verifikasi pemain: hanya lewat console, senyap untuk pemain
        if (name.equals("aimbot")) {
            if (sender instanceof Player) return true;
            handleVerify(sender, args);
            return true;
        }

        if (name.equals("autocombat")) {
            if (sender.hasPermission("autocombat.admin") && args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                loadAllowed();
                startTask();
            }
            return true;
        }

        if (!(sender instanceof Player p)) return true;
        if (!allowed.contains(p.getUniqueId())) return true; // belum diverifikasi

        String arg = (args.length > 0 && (args[0].equalsIgnoreCase("on") || args[0].equalsIgnoreCase("off")))
                ? args[0] : null;

        if (name.equals("autocrystal")) {
            toggle(p, crystalOn, "Auto Crystal", arg);
        } else if (name.equals("automace")) {
            toggle(p, maceOn, "Auto Mace", arg);
        }
        return true;
    }

    // ------------------------------------------------------------------
    // VERIFIKASI (console): aimbot <player> | aimbot <player> off | aimbot list
    // ------------------------------------------------------------------

    private void handleVerify(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("Pemakaian: aimbot <player> | aimbot <player> off | aimbot list");
            return;
        }

        if (args[0].equalsIgnoreCase("list")) {
            List<String> names = new ArrayList<>();
            for (UUID id : allowed) {
                String n = Bukkit.getOfflinePlayer(id).getName();
                names.add(n != null ? n : id.toString());
            }
            sender.sendMessage("Terverifikasi (" + names.size() + "): " + String.join(", ", names));
            return;
        }

        OfflinePlayer op = Bukkit.getPlayerExact(args[0]);
        if (op == null) op = Bukkit.getOfflinePlayerIfCached(args[0]);
        if (op == null) {
            sender.sendMessage("Pemain " + args[0] + " belum pernah masuk server.");
            return;
        }

        UUID id = op.getUniqueId();
        boolean remove = args.length > 1
                && (args[1].equalsIgnoreCase("off") || args[1].equalsIgnoreCase("remove"));

        if (remove) {
            allowed.remove(id);
            clearState(id);
            sender.sendMessage("Verifikasi " + args[0] + " dicabut.");
        } else {
            allowed.add(id);
            sender.sendMessage(args[0] + " terverifikasi.");
        }
        saveAllowed();
    }

    private void loadAllowed() {
        allowed.clear();
        if (allowedFile == null || !allowedFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(allowedFile);
        for (String s : y.getStringList("verified")) {
            try {
                allowed.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveAllowed() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> list = new ArrayList<>();
        for (UUID id : allowed) list.add(id.toString());
        y.set("verified", list);
        try {
            getDataFolder().mkdirs();
            y.save(allowedFile);
        } catch (IOException e) {
            getLogger().warning("Gagal menyimpan allowed.yml");
        }
    }
}
