# AutoCombat v1.3

Plugin Paper 1.21.11 (Java 21) berisi dua fitur dalam satu plugin:

- **Auto End Crystal** (`/autocrystal [on|off]`): aktif hanya saat End Crystal dipegang. Mencari obsidian/bedrock maksimal 2 blok dari target (makin dekat makin diprioritaskan), memasang crystal lalu langsung meledakkannya di tick yang sama. Layar pemain tidak pernah digerakkan.
- **Auto Mace** (`/automace [on|off]`): saat jatuh, layar mengunci target di bawah (pemain, mob, bot) dengan gerak halus dan batas kecepatan putar. Kill aura memukul target terdekat dalam jangkauan.

Tidak ada pesan chat. Umpan balik toggle bisa dinyalakan lewat `feedback: "actionbar"` di `config.yml`.

## Build

Butuh JDK 21 dan Maven.

```
mvn package
```

Hasilnya `target/AutoCombat.jar`. Taruh di folder `plugins/` server lalu restart.

Kalau update dari versi lama, hapus `plugins/AutoCombat/config.yml` lama sebelum restart supaya config baru dibuat.

## Verifikasi pemain (lewat console)

Hanya pemain yang sudah diverifikasi yang bisa memakai `/autocrystal` dan `/automace`. Pemain lain tidak mendapat respons apa pun.

- `aimbot <player>`: verifikasi pemain
- `aimbot <player> off`: cabut verifikasi
- `aimbot list`: lihat daftar

Command `aimbot` hanya bisa dari console. Pemain yang sudah pernah masuk server bisa diverifikasi. Daftar disimpan di `plugins/AutoCombat/allowed.yml`.

## Permission

- `autocombat.admin` (untuk `/autocombat reload`)

## Pengaturan

Semua angka (jangkauan, delay, jarak obsidian, kehalusan layar, kill aura, dll) ada di `plugins/AutoCombat/config.yml`.
