# AutoCombat v1.4.2

Plugin Paper 1.21.11 (Java 21), server-side. Karena jalan di server, pemain **Java** dan **Bedrock (Geyser/Floodgate)** sama-sama bisa memakainya.

## Fitur

- **Auto End Crystal** (`/autoendcrystal [on|off]`, alias `/autocrystal`, `/aec`, `/endcrystal`): aktif hanya saat End Crystal dipegang. Memasang crystal di dasar yang ada dekat target lalu meledakkannya. Layar tidak pernah digerakkan.
- **Auto Mace** (`/automace [on|off]`, alias `/am`): saat jatuh, kamera mengikuti target di bawah secara halus (ada waktu reaksi, deadzone, titik bidik acak di dalam hitbox, batas kecepatan kecil). Posisi dan kecepatan jatuh tidak pernah diubah. Pukulan hanya terjadi kalau crosshair benar-benar mengenai target.

## Perubahan v1.4

- `/autocrystal` diganti `/autoendcrystal` (alias lama tetap bisa dipakai).
- Mace: kamera tidak lagi menyentak. Putaran maksimal 4 derajat/tick, update tiap 2 tick, berhenti menarik kalau crosshair sudah di target.
- Mace: kill aura tanpa menghadap dimatikan secara default (`mace.require-facing: true`).
- Crystal: dasar crystal bisa diatur lewat `crystal.base-blocks`, `hit-mobs` default true supaya bot/NPC ikut kena, ada jeda pasang -> ledak.
- Verifikasi: nama Bedrock (`.Nama`) dan nama tanpa titik sama-sama dikenali, atau pakai UUID.
- `feedback` default `actionbar` supaya kelihatan toggle on/off (hanya terlihat oleh pemainnya).

## Build

Butuh JDK 21 dan Maven: `mvn package` -> `target/AutoCombat.jar`. Atau dorong ke GitHub, workflow `build-autocombat.yml` akan membangunnya.

Hapus `plugins/AutoCombat/config.yml` lama sebelum restart supaya config baru dibuat.

## Verifikasi pemain (lewat console)

Hanya pemain terverifikasi yang bisa memakai command. Pemain lain tidak mendapat respons.

- `aimbot <player|uuid>`: verifikasi
- `aimbot <player> off`: cabut
- `aimbot list`: daftar

Bedrock: boleh `aimbot .NamaKamu` atau `aimbot NamaKamu`. Pemain harus pernah masuk server. Daftar disimpan di `plugins/AutoCombat/allowed.yml`.

## Permission

- `autocombat.admin` (untuk `/autocombat reload`)
